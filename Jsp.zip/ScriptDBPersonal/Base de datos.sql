-- CREAMOS BASE DE DATOS
drop database if exists DBPersonal;
create database DBPersonal;
use DBPersonal;

-- CREAR TABLAS 
-- TABLAS DE LOGIN
 create table Usuarios(
	Email varchar(100) CHECK (Email like '%_@interbank.pe') not null,
	Contraseña varchar(100) not null,
	primary key(Email)
 );
 
 insert into Usuarios(Email, Contraseña)
 values("123456@interbank.pe","drussila");
 
select * from Usuarios;
-- PROCEDIMIENTOS ALMACENADOS
use DBPersonal;
drop procedure if exists spBuscarEmpleados;
delimiter //
create procedure spBuscarEmpleados(
	in 
    _email varchar(100)
)
begin
	select Contraseña from Usuarios where _email = Email;
end //
delimiter ;

call spBuscarEmpleados("123456@interbank.pe");
select * from Usuarios;
select*from asociados;

select * from solicitud;

select * from cuota;

drop table if exists cuota;
CREATE TABLE cuota (
  IdCuota int NOT NULL auto_increment primary key,
  IdSolicitud int not NULL,
  NCuota int,
  Saldo double,
  Capital double,
  Interes double,
  Monto double,
  FechaDePago date
) ;

alter table cuota add foreign key (IdSolicitud) references Solicitud(IdSolicitud);

drop procedure if exists spInsertarCuota;
delimiter //
CREATE PROCEDURE spInsertarCuota(
	in 
    _idCuota int,
    _idSolicitud int,
    _nCuota int,
    _saldo double,
    _capital double,
    _interes double,
    _monto double,
    _fechaDePago date  
    
)
begin
	insert into Cuota(IdCuota, IdSolicitud, NCuota, Saldo, Capital, Interes, Monto, FechaDePago)
    values(_idCuota,_idSolicitud, _nCuota, _saldo, _capital, _interes, _monto, _fechaDePago);
end//
delimiter ;
call spInsertarCuota(1,1,1,800,100,0.07,110,"2004-02-10");
select * from cuota;

 drop procedure if exists spGenerarCronograma;
 delimiter //
 create procedure spGenerarCronograma(in _idSolicitud int)
 begin
	declare _estado varchar(10);
	declare _ncuota int;
    declare _saldo double;
    declare _capital double;
    declare _interes double;
    declare _tasa double;
    declare _monto double;
    declare _fechaPrestamo date;
    declare _fechaPago date;
    declare n int;
    
    SET _estado = (SELECT Estado from solicitud where IdSolicitud = _idSolicitud);
    IF _estado = "APROBADO" THEN
    set _ncuota = (select NCuotas from solicitud where IdSolicitud = _idSolicitud);
    set _saldo = (select Monto from solicitud where IdSolicitud = _idSolicitud);
    set _tasa = (select Taza from solicitud where IdSolicitud = _idSolicitud);
    set _fechaPrestamo = (select Fecha from solicitud where IdSolicitud = _idSolicitud);
    set _capital = _saldo / _ncuota;
    set _interes = _tasa * _saldo;
    set _monto = _capital + _interes;
    set _fechaPago = date_add(_fechaPrestamo, interval 1 month);
    
    delete from cuota where IdSolicitud = _idSolicitud;
    
    set n = 1;
    while n<=_ncuota do
		insert into cuota(IdSolicitud,NCuota,Saldo,Capital,Interes,Monto,FechaDePago)
        values(_idSolicitud, n,_saldo,_capital,_interes,_monto,_fechaPago);
        set n = n+1;
        set _fechaPago = date_add(_fechaPago, interval 1 month);
	end while;
    END IF;
 end//
 delimiter ;
 
 select * from cuota;
 SELECT*FROM solicitud;
 SELECT*FROM cuota;
 CALL spGenerarCronograma(11);
 /*call spActualizarEstado(36,'PENDIENTE')*/