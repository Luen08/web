call spActualizarAsociado('45678912','xxxx','xxxx','xxxx','2006-03-05',18,'xxxx@gmail.com',1000.0,'dasds');
select * from asociados;
drop procedure if exists spActualizarAsociado;
delimiter //
CREATE PROCEDURE spActualizarAsociado(
	in 
    _dni char(8),
    _contraseña varchar(150),
	_nombre varchar(50),
    _apellidos varchar(150),
    _fechaNacimiento date,
    _edad int,
    _email varchar(100),
    _salario double,
    _empresa varchar (50)
)
begin
    update asociados set Contraseña = _contraseña, Nombre = _nombre, Apellidos = _apellidos, FechaNacimiento =_fechaNacimiento, Edad = _edad, Email = _email, Salario = _salario, Empresa = _empresa where Dni = _dni;
end //
delimiter ;
select*from asociados;

call spInsertarSolicitud('12345678',null,curdate(),4,800.0,0.06,'POBRE');
select* from solicitud;
CALL spVistaSolicitudes('12345678');

drop procedure if exists spInsertarSolicitud;
delimiter //
CREATE PROCEDURE spInsertarSolicitud(
	in 
    _dni char(8),
    _idSolicitud int,
    _nCuotas int,
    _monto double,
    _taza double,
    _observaciones varchar(150)
)
begin
	insert into Solicitud(Dni, IdSolicitud, Fecha, NCuotas, Monto, Taza, Observaciones, Estado)
    values(_dni, _idSolicitud, curdate(), _nCuotas, _monto, _taza, _observaciones, "PENDIENTE");
end //
delimiter ;

select * from solicitud;

