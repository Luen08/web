

 $('#btnRegistro').click(function(){
	$('#formulario-registro').modal('show');
});