package com.proyecto.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	public Connection Conectar() throws ClassNotFoundException {
		String servidor="jdbc:mysql://localhost:3306/dbpersonal?useTimezone=true&serverTimezone=UTC";
		String usuario="root";
		String password="cjoxvwdk222";
		String driver="com.mysql.cj.jdbc.Driver";
		Connection cn = null;
		
		Class.forName(driver);

		try {
			cn = DriverManager.getConnection(servidor, usuario, password);
			System.out.println("Conexion realizada con exito!!");
			return cn;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("todo mal");
			return cn;
		}
		
	}
	
}
