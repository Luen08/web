package com.proyecto.controladores;
import com.proyecto.modelo.Asociados;
import com.proyecto.modelo.Usuarios;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proyecto.modelo.Usuarios;

/**
 * Servlet implementation class ControladorUsuarios
 */
@WebServlet("/ControladorUsuarios")
public class ControladorUsuarios extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControladorUsuarios() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		
		
		if(action.equals("regresar")) {
			Asociados aso = new Asociados();
			try {
				aso.Conexion();
				Object[][] lista = aso.vistaAsociados();
				
				request.setAttribute("lista", lista); // crear atributos
				RequestDispatcher rd = request.getRequestDispatcher("vistaEmpleado.jsp");
				rd.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		//CAPTURAR VALORES DE FORMULARIO
		String Email = request.getParameter("Email");
		String pwd = request.getParameter("PasswordEmail");
		String action = request.getParameter("action");
		
		Usuarios user = new Usuarios();
		
		if(action.equals("ingresarEmpleados")) {
			user.setEmail(Email);
			user.setContraseña(pwd);
			
			try {
				user.Conexion();
				String Contraseña = user.buscarEmpleados(); // variable de la contraseña
				
				
				if(user.getContraseña().equals(Contraseña)) {
					Asociados aso = new Asociados();
					aso.Conexion();
					Object[][] lista = aso.vistaAsociados();
					
					request.setAttribute("lista", lista); // crear atributos
					RequestDispatcher rd = request.getRequestDispatcher("vistaEmpleado.jsp");
					rd.forward(request, response);
				}else if(!(user.getContraseña().equals(Contraseña))) {
					response.sendRedirect("index.jsp");
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
