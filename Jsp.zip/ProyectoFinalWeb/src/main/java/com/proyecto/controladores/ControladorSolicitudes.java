package com.proyecto.controladores;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proyecto.modelo.Solicitudes;

/**
 * Servlet implementation class ControladorSolicitudes
 */
@WebServlet("/ControladorSolicitudes")
public class ControladorSolicitudes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControladorSolicitudes() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Solicitudes soli = new Solicitudes();
		String Dni = request.getParameter("Dni");
		String action = request.getParameter("action");
		soli.setDni(Dni);
		
		if(action.equals("vista")) {
			try {
				soli.Conexion();
				
				Object[][] solicitudes = soli.vistaSolicitudes();
				request.setAttribute("lista", solicitudes);
				request.setAttribute("Dni", Dni);
				RequestDispatcher rd = request.getRequestDispatcher("/views/Solicitudes.jsp");
				rd.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("solicitar")) {
			try {
				soli.Conexion();
				request.setAttribute("Dni", Dni);
				RequestDispatcher rd = request.getRequestDispatcher("/SolicitaCredito.jsp");
				rd.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("regresar")) {
			String Dni1 = request.getParameter("Dni");
			System.out.print(Dni1);
			request.setAttribute("Dni",Dni1 );
			RequestDispatcher rdvistaCliente = request.getRequestDispatcher("/vistaCliente.jsp");
			rdvistaCliente.forward(request, response);
		}else if(action.equals("vistaEmpleado")) {
			try {
				soli.Conexion();
				
				Object[][] solicitudes = soli.vistaSolicitudes();
				request.setAttribute("lista", solicitudes);
				request.setAttribute("Dni", Dni);
				RequestDispatcher rd = request.getRequestDispatcher("/views/SolicitudesEmpleados.jsp");
				rd.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("APROBADO")) {
			try {
				soli.Conexion();
				String idSolicitud = request.getParameter("idSolicitud");
				String Dni2 = request.getParameter("Dni");
				String estado = action;
				String actionget = "cronograma";
				
				soli.setIdSolicitud(idSolicitud);
				soli.setEstado(estado);
				soli.ActualizarEstado();
				
				
				response.sendRedirect("ControladorCuotas?action="+actionget+"&Dni="+Dni2+"&idSolicitud="+idSolicitud);
				
				
				
				//response.sendRedirect("ControladorSolicitudes?action=vistaEmpleado&Dni="+Dni2);
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("RECHAZADO")) {
			try {
				soli.Conexion();
				String idSolicitud = request.getParameter("idSolicitud");
				String Dni2 = request.getParameter("Dni");
				String estado = action;
				
				soli.setIdSolicitud(idSolicitud);
				soli.setEstado(estado);
				soli.ActualizarEstado();
				response.sendRedirect("ControladorSolicitudes?action=vistaEmpleado&Dni="+Dni2);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		Solicitudes soli = new Solicitudes();
		String action = request.getParameter("action");
		
		String dni = request.getParameter("Dni");
		String ncuotas = request.getParameter("NCuotas");
		String monto = request.getParameter("Monto");
		String tasa = request.getParameter("Tasa");
		String observaciones = request.getParameter("Observaciones");
		
			if(action.equals("insertarsoli")) {
				try {
					soli.Conexion();
					soli.setDni(dni);
					soli.setIdSolicitud(null);
					soli.setNCuotas(Integer.parseInt(ncuotas));
					soli.setMonto(Double.parseDouble(monto));
					soli.setTasa(Double.parseDouble(tasa));
					soli.setObservaciones(observaciones);
					soli.CrearSolicitud();
					System.out.print(soli.getDni());
					
					response.sendRedirect("ControladorSolicitudes?action=vista&Dni="+soli.getDni());
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		
		

	}
}
