package com.proyecto.controladores;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proyecto.modelo.Cuotas;

/**
 * Servlet implementation class ControladorCuotas
 */
@WebServlet("/ControladorCuotas")
public class ControladorCuotas extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControladorCuotas() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		
		if(action.equals("cronograma")) {
			int idSolicitud = Integer.parseInt(request.getParameter("idSolicitud"));
			String Dni = request.getParameter("Dni");
			Cuotas cuo = new Cuotas();
			try {
				cuo.Conexion();
				cuo.setIdSolicitud(idSolicitud);
				cuo.GenerarCronograma();
				
				response.sendRedirect("ControladorSolicitudes?action=vistaEmpleado&idSolicitud="+idSolicitud+"&Dni="+Dni);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("vistaCuotas")) {
			Cuotas cuo = new Cuotas();
			try {
				cuo.Conexion();
				int idSolicitud = Integer.parseInt(request.getParameter("idSolicitud"));
				String Dni = request.getParameter("Dni");
				cuo.setIdSolicitud(idSolicitud);
				Object[][] listacuotas = cuo.vistaCuotas();
				request.setAttribute("listacuotas",listacuotas );
				request.setAttribute("Dni", Dni);
				RequestDispatcher rdvistaCuotas = request.getRequestDispatcher("/views/cronograma.jsp");
				rdvistaCuotas.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}else if(action.equals("vistaCuotasCliente")) {
			Cuotas cuo = new Cuotas();
			try {
				cuo.Conexion();
				int idSolicitud = Integer.parseInt(request.getParameter("idSolicitud"));
				String Dni = request.getParameter("Dni");
				cuo.setIdSolicitud(idSolicitud);
				Object[][] listacuotas = cuo.vistaCuotas();
				request.setAttribute("listacuotas",listacuotas );
				request.setAttribute("Dni", Dni);
				RequestDispatcher rdvistaCuotas = request.getRequestDispatcher("/views/cronogramacliente.jsp");
				rdvistaCuotas.forward(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
	}

}
