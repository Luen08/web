package com.proyecto.controladores;

import java.io.IOException;
import java.sql.SQLException;
import java.time.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proyecto.modelo.Asociados;

/**
 * Servlet implementation class ControladorAsociado
 */
@WebServlet("/ControladorAsociado")
public class ControladorAsociado extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControladorAsociado() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Asociados asoget = new Asociados();
		try {
			asoget.Conexion();
			String action = request.getParameter("action");
			String Dni = request.getParameter("Dni");
			
			if(action.equals("perfil")) {
				asoget.setDni(Dni);
				Object[][] dates = new Object[1][9];
				dates = asoget.buscarAsociado();
				
				String contraseña = (String)dates[0][1];
				String fecha = (String)dates[0][4];
				String edad = (String)dates[0][5];
				String Salario = (String)dates[0][7];
				
				asoget.setDni((String)dates[0][0]);
				asoget.setContraseña(contraseña);
				asoget.setNombre((String)dates[0][2]);
				asoget.setApellidos((String)dates[0][3]);
				asoget.setFechaNacimiento(java.sql.Date.valueOf(fecha).toLocalDate());
				asoget.setEdad(Integer.parseInt(edad));
				asoget.setEmail((String)dates[0][6]);
				asoget.setSalario(Double.parseDouble(Salario));
				asoget.setEmpresa((String)dates[0][8]);

				request.setAttribute("Dni", asoget.getDni()); // crear atributos
				request.setAttribute("Contraseña", asoget.getContraseña());
				request.setAttribute("Nombre", asoget.getNombre());
				request.setAttribute("Apellidos", asoget.getApellidos());
				request.setAttribute("FechaNacimiento", asoget.getFechaNacimiento());
				request.setAttribute("Edad", asoget.getEdad());
				request.setAttribute("Email", asoget.getEmail());
				request.setAttribute("Salario", asoget.getSalario());
				request.setAttribute("Empresa", asoget.getEmpresa());
				RequestDispatcher rdvistaPerfil = request.getRequestDispatcher("vistaPerfil.jsp");
				rdvistaPerfil.forward(request, response);
				
			}else if(action.equals("regresar")) {
				String Dni1 = request.getParameter("Dni");
				System.out.print(Dni1);
				request.setAttribute("Dni",Dni1 );
				RequestDispatcher rdvistaCliente = request.getRequestDispatcher("/vistaCliente.jsp");
				rdvistaCliente.forward(request, response);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		Asociados aso = new Asociados();
		String action = request.getParameter("action");
		
		if(action.equals("ingresar")) {
			String Dni = request.getParameter("Dni");
			String pwd = request.getParameter("PasswordDni");
			aso.setDni(Dni);
			aso.setContraseña(pwd);
			try {
				aso.Conexion();
				Object[][] dates = new Object[1][9];
				dates = aso.buscarAsociado();
				String contraseña = (String)dates[0][1];
				String fecha = (String)dates[0][4];
				String edad = (String)dates[0][5];
				String Salario = (String)dates[0][7];
				if(aso.getContraseña().equals(contraseña)) {
					aso.setDni((String)dates[0][0]);
					aso.setContraseña(contraseña);
					aso.setNombre((String)dates[0][2]);
					aso.setApellidos((String)dates[0][3]);
					aso.setFechaNacimiento(java.sql.Date.valueOf(fecha).toLocalDate()); //error boostrap
					aso.setEdad(Integer.parseInt(edad));
					aso.setEmail((String)dates[0][6]);
					aso.setSalario(Double.parseDouble(Salario));
					aso.setEmpresa((String)dates[0][8]);
					
					request.setAttribute("Dni", aso.getDni()); // crear atributos
					request.setAttribute("Contraseña", aso.getContraseña());
					request.setAttribute("Nombre", aso.getNombre());
					request.setAttribute("Apellidos", aso.getApellidos());
					request.setAttribute("FechaNacimiento", aso.getFechaNacimiento());
					request.setAttribute("Edad", aso.getEdad());
					request.setAttribute("Email", aso.getEmail());
					request.setAttribute("Salario", aso.getSalario());
					request.setAttribute("Empresa", aso.getEmpresa());
					RequestDispatcher rdvistacliente = request.getRequestDispatcher("vistaCliente.jsp");
					rdvistacliente.forward(request, response);
					RequestDispatcher rdnavBar = request.getRequestDispatcher("navBar.jsp");
					rdnavBar.forward(request, response);
				}else {
					response.sendRedirect("index.jsp");
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(action.equals("actualizar")) {
			String fecha = request.getParameter("FechaNacimiento");
			String edad = request.getParameter("Edad");
			String salario = request.getParameter("Salario");


			String Dni = request.getParameter("Dni");
			String Contraseña = request.getParameter("Password");
			String Nombre = request.getParameter("Nombre");
			String Apellidos = request.getParameter("Apellidos");
			LocalDate FechaNacimiento = java.sql.Date.valueOf(fecha).toLocalDate();
			int Edad = Integer.parseInt(edad);
			String Email = request.getParameter("Email");
			Double Salario = Double.parseDouble(salario);
			String Empresa = request.getParameter("Empresa");
			
			try {
				aso.Conexion();
				
				aso.setDni(Dni);
				aso.setContraseña(Contraseña);
				aso.setNombre(Nombre);
				aso.setApellidos(Apellidos);
				aso.setFechaNacimiento(FechaNacimiento);
				aso.setEdad(Edad);
				aso.setEmail(Email);
				aso.setSalario(Salario);
				aso.setEmpresa(Empresa);
				
				aso.ActualizarAsociado();
				
				response.sendRedirect("ControladorAsociado?action=regresar&Dni="+aso.getDni());
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if(action.equals("registro")){
			
			String fecha = request.getParameter("FechaRegistro");
			String edad = request.getParameter("EdadRegistro");
			String salario = request.getParameter("SalarioRegistro");
			
			String Dni = request.getParameter("DniRegistro");
			String Contraseña = request.getParameter("PasswordRegistro");
			String Nombre = request.getParameter("NombreRegistro");
			String Apellidos = request.getParameter("ApellidosRegistro");
			LocalDate FechaNacimiento = java.sql.Date.valueOf(fecha).toLocalDate();
			int Edad = Integer.parseInt(edad);
			String Email = request.getParameter("EmailRegistro");
			Double Salario = Double.parseDouble(salario);
			String Empresa = request.getParameter("EmpresaRegistro");
			
			try {
				aso.Conexion();
				aso.setDni(Dni);
				aso.setContraseña(Contraseña);
				aso.setNombre(Nombre);
				aso.setApellidos(Apellidos);
				aso.setFechaNacimiento(FechaNacimiento);
				aso.setEdad(Edad);
				aso.setEmail(Email);
				aso.setSalario(Salario);
				aso.setEmpresa(Empresa);
				aso.CrearAsociado();
				
				response.sendRedirect("index.jsp");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
