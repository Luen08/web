package com.proyecto.modelo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.proyecto.conexion.Conexion;

public class Asociados {
	private String Dni;
	private String Contraseña;
	private String Nombre;
	private String Apellidos;
	private LocalDate FechaNacimiento;
	private int Edad;
	private String Email;
	private Double Salario;
	private String Empresa;
	
	public Connection Conexion;
	static CallableStatement stmt = null;
	static ResultSet rs = null;
	public String getDni() {
		return Dni;
	}
	public void setDni(String dni) {
		Dni = dni;
	}
	public String getContraseña() {
		return Contraseña;
	}
	public void setContraseña(String contraseña) {
		Contraseña = contraseña;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getApellidos() {
		return Apellidos;
	}
	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}
	public LocalDate getFechaNacimiento() {
		return FechaNacimiento;
	}
	public void setFechaNacimiento(LocalDate fechaNacimiento) {
		FechaNacimiento = fechaNacimiento;
	}
	public int getEdad() {
		return Edad;
	}
	public void setEdad(int edad) {
		Edad = edad;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Double getSalario() {
		return Salario;
	}
	public void setSalario(Double salario) {
		Salario = salario;
	}
	public String getEmpresa() {
		return Empresa;
	}
	public void setEmpresa(String empresa) {
		Empresa = empresa;
	}
	
	public void Conexion() throws ClassNotFoundException {
		Conexion conex = new Conexion();
		Conexion = conex.Conectar();
	}
	
	public Object[][] buscarAsociado() throws SQLException {
		String sqlSp = "{call spBuscarAsociado(?)}";
		
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setString(1, Dni);
			rs = stmt.executeQuery();
			Object[][] Datos = new Object[1][9];
			rs.beforeFirst();
			rs.next();
			Datos [0][0] = rs.getString(1);
			Datos [0][1] = rs.getString(2); // contraseña
			Datos [0][2] = rs.getString(3);
			Datos [0][3] = rs.getString(4);
			Datos [0][4] = rs.getString(5);
			Datos [0][5] = rs.getString(6);
			Datos [0][6] = rs.getString(7);
			Datos [0][7] = rs.getString(8);
			Datos [0][8] = rs.getString(9);
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return Datos;
			
		
	}
	
	
	public boolean CrearAsociado() {
		String sqlSp = "{call spInsertarAsociado(?,?,?,?,?,?,?,?,?)}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setString(1, Dni);
			stmt.setString(2, Contraseña);
			stmt.setString(3, Nombre);
			stmt.setString(4, Apellidos);
			stmt.setDate(5, java.sql.Date.valueOf(FechaNacimiento));
			stmt.setInt(6, Edad);
			stmt.setString(7, Email);
			stmt.setDouble(8, Salario);
			stmt.setString(9, Empresa);
			
			stmt.execute();
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
		
	}
	
	public boolean ActualizarAsociado() throws SQLException {
		String sqlSp = "{call spActualizarAsociado(?,?,?,?,?,?,?,?,?)}";
		
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setString(1, Dni);
			stmt.setString(2, Contraseña);
			stmt.setString(3, Nombre);
			stmt.setString(4, Apellidos);
			stmt.setDate(5, java.sql.Date.valueOf(FechaNacimiento));
			stmt.setInt(6, Edad);
			stmt.setString(7, Email);
			stmt.setDouble(8, Salario);
			stmt.setString(9, Empresa);
			
			stmt.execute();
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return true;
			
	}
	public Object[][] vistaAsociados() {
		String sqlSp = "{call spVistaTotalAsociados()}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			
			rs = stmt.executeQuery();
			rs.last();
			Object[][] DatosSolicitudes = new Object[rs.getRow()][8];
			rs.beforeFirst();
			while(rs.next()) {
				DatosSolicitudes[rs.getRow()-1][0] = rs.getString(1);
				DatosSolicitudes[rs.getRow()-1][1] = rs.getString(3);
				DatosSolicitudes[rs.getRow()-1][2] = rs.getString(4);
				DatosSolicitudes[rs.getRow()-1][3] = rs.getString(5);
				DatosSolicitudes[rs.getRow()-1][4] = rs.getString(6);
				DatosSolicitudes[rs.getRow()-1][5] = rs.getString(7);
				DatosSolicitudes[rs.getRow()-1][6] = rs.getString(8);
				DatosSolicitudes[rs.getRow()-1][7] = rs.getString(9);

			}
					
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return DatosSolicitudes;
		}catch(SQLException e){
			e.printStackTrace();
			return null;
		}
	}
}
