package com.proyecto.modelo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.proyecto.conexion.Conexion;

public class Cuotas {
	private int IdCuota;
	private int IdSolicitud;
	private int NCuota;
	private Double Saldo;
	private Double Capital;
	private Double Interes;
	private Double Monto;
	private LocalDate FechaDePago;
	
	public Connection Conexion;
	static CallableStatement stmt = null;
	static ResultSet rs = null;
	
	public int getIdCuota() {
		return IdCuota;
	}
	public void setIdCuota(int idCuota) {
		IdCuota = idCuota;
	}
	public int getIdSolicitud() {
		return IdSolicitud;
	}
	public void setIdSolicitud(int idSolicitud) {
		IdSolicitud = idSolicitud;
	}
	public int getNCuota() {
		return NCuota;
	}
	public void setNCuota(int nCuota) {
		NCuota = nCuota;
	}
	public Double getSaldo() {
		return Saldo;
	}
	public void setSaldo(Double saldo) {
		Saldo = saldo;
	}
	public Double getCapital() {
		return Capital;
	}
	public void setCapital(Double capital) {
		Capital = capital;
	}
	public Double getInteres() {
		return Interes;
	}
	public void setInteres(Double interes) {
		Interes = interes;
	}
	public Double getMonto() {
		return Monto;
	}
	public void setMonto(Double monto) {
		Monto = monto;
	}
	public LocalDate getFechaDePago() {
		return FechaDePago;
	}
	public void setFechaDePago(LocalDate fechaDePago) {
		FechaDePago = fechaDePago;
	}
	
	public void Conexion() throws ClassNotFoundException {
		Conexion conex = new Conexion();
		Conexion = conex.Conectar();
	}
	
	public boolean GenerarCronograma() {
		String sqlSp = "{call spGenerarCronograma(?)}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setInt(1, IdSolicitud);
			
			stmt.execute();
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
		
	}
	
	public Object[][] vistaCuotas(){
		String sqlSp = "{call spVistaCuotas(?)}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setInt(1, IdSolicitud);
			
			rs = stmt.executeQuery();
			rs.last();
			Object[][] DatosCuotas = new Object[rs.getRow()][8];
			rs.beforeFirst();
			while(rs.next()) {
				DatosCuotas[rs.getRow()-1][0] = rs.getString(1);
				DatosCuotas[rs.getRow()-1][1] = rs.getString(2);
				DatosCuotas[rs.getRow()-1][2] = rs.getString(3);
				DatosCuotas[rs.getRow()-1][3] = rs.getString(4);
				DatosCuotas[rs.getRow()-1][4] = rs.getString(5);
				DatosCuotas[rs.getRow()-1][5] = rs.getString(6);
				DatosCuotas[rs.getRow()-1][6] = rs.getString(7);
				DatosCuotas[rs.getRow()-1][7] = rs.getString(8);
			}
					
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return DatosCuotas;
		}catch(SQLException e){
			e.printStackTrace();
			return null;
		}
	}
}
