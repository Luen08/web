package com.proyecto.modelo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.proyecto.conexion.Conexion;

public class Solicitudes {
	private String Dni;
	private String IdSolicitud;
	private LocalDate Fecha;
	private int NCuotas;
	private Double Monto;
	private Double Tasa;
	private String Observaciones;
	private String Estado;
	
	public Connection Conexion;
	static CallableStatement stmt = null;
	static ResultSet rs = null;
	public String getDni() {
		return Dni;
	}
	public void setDni(String dni) {
		Dni = dni;
	}
	public String getIdSolicitud() {
		return IdSolicitud;
	}
	public void setIdSolicitud(String idSolicitud) {
		IdSolicitud = idSolicitud;
	}
	public LocalDate getFecha() {
		return Fecha;
	}
	public void setFecha(LocalDate fecha) {
		Fecha = fecha;
	}
	public int getNCuotas() {
		return NCuotas;
	}
	public void setNCuotas(int nCuotas) {
		NCuotas = nCuotas;
	}
	public Double getMonto() {
		return Monto;
	}
	public void setMonto(Double monto) {
		Monto = monto;
	}
	public Double getTasa() {
		return Tasa;
	}
	public void setTasa(Double tasa) {
		Tasa = tasa;
	}
	public String getObservaciones() {
		return Observaciones;
	}
	public void setObservaciones(String observaciones) {
		Observaciones = observaciones;
	}
	public String getEstado() {
		return Estado;
	}
	public void setEstado(String estado) {
		Estado = estado;
	}
	
	public void Conexion() throws ClassNotFoundException {
		Conexion conex = new Conexion();
		Conexion = conex.Conectar();
	}
	
	public boolean CrearSolicitud() {
		String sqlSp = "{call spInsertarSolicitud(?,?,?,?,?,?)}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setString(1, Dni);
			stmt.setString(2, IdSolicitud);
			stmt.setInt(3, NCuotas);
			stmt.setDouble(4, Monto);
			stmt.setDouble(5, Tasa);
			stmt.setString(6, Observaciones);
			
			stmt.execute();
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
		
	}
	
	public boolean ActualizarEstado() {
		String sqlSp = "{call spActualizarEstado(?,?)}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setString(1, IdSolicitud);
			stmt.setString(2, Estado);
			
			stmt.execute();
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
			return false;
		}
	}
	
	public Object[][] vistaSolicitudes() {
		String sqlSp = "{call spVistaSolicitudes(?)}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setString(1, Dni);
			
			rs = stmt.executeQuery();
			rs.last();
			Object[][] DatosSolicitudes = new Object[rs.getRow()][8];
			rs.beforeFirst();
			while(rs.next()) {
				DatosSolicitudes[rs.getRow()-1][0] = rs.getString(1);
				DatosSolicitudes[rs.getRow()-1][1] = rs.getString(2);
				DatosSolicitudes[rs.getRow()-1][2] = rs.getString(3);
				DatosSolicitudes[rs.getRow()-1][3] = rs.getString(4);
				DatosSolicitudes[rs.getRow()-1][4] = rs.getString(5);
				DatosSolicitudes[rs.getRow()-1][5] = rs.getString(6);
				DatosSolicitudes[rs.getRow()-1][6] = rs.getString(7);
				DatosSolicitudes[rs.getRow()-1][7] = rs.getString(8);
			}
					
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return DatosSolicitudes;
		}catch(SQLException e){
			e.printStackTrace();
			return null;
		}
	}
	
	
}
