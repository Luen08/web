package com.proyecto.modelo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.sql.ResultSet;

import com.proyecto.conexion.Conexion;
public class Usuarios {
	private String Email;
	private String Contraseña;
	public Connection Conexion;
	
	static CallableStatement stmt = null;
	static ResultSet rs = null;
	
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getContraseña() {
		return Contraseña;
	}
	public void setContraseña(String contraseña) {
		Contraseña = contraseña;
	}
	
	//conecta el modelo usuario a la base de datos
	
	public void Conexion() throws ClassNotFoundException {
		Conexion conex = new Conexion();
		Conexion = conex.Conectar();
	}
	
	// metodo buscar para login
	public String buscarEmpleados() {
		String sqlSp = "{call spBuscarEmpleados(?)}";
		try {
			stmt = Conexion.prepareCall(sqlSp);
			stmt.setString(1, Email);
			rs = stmt.executeQuery();
			//String contraseña = rs.getString("Contraseña"); //no funciona con variables solo con objetos resultSet
			rs.last();
			Object[][] contra = new Object[rs.getRow()][1];
			rs.beforeFirst();
			rs.next();
			contra [rs.getRow()-1][0] = rs.getString(1);
			String contraseña = (String)contra[0][0];
			stmt.clearParameters();
			stmt.close();
			Conexion.close();
			return contraseña;
			
		}catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
}
