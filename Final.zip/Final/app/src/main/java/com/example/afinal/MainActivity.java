package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.afinal.db.DbHelper;


public class MainActivity extends AppCompatActivity {
    Button btnCrear;

    public void irRegistrar (View view){
        Intent i = new Intent(this, Registrar.class);
        startActivity(i);
    }

    public void irMostrar (View view){
        Intent i = new Intent(this, Mostrar.class);
        startActivity(i);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCrear = findViewById(R.id.btnCrearDb);

        btnCrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DbHelper i = new DbHelper(MainActivity.this);
                SQLiteDatabase db = i.getWritableDatabase();


                if(db != null){
                        Toast.makeText(MainActivity.this,"BASE DE DATOS CREADA", Toast.LENGTH_LONG).show();

                    }else{
                        Toast.makeText(MainActivity.this,"NO CREADA", Toast.LENGTH_LONG).show();
                    }






                }



        });
    }
}