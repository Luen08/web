package com.example.afinal.adapatadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.afinal.R;
import com.example.afinal.entidades.Personas;

import java.util.ArrayList;

public class listaPersonasAdapter extends RecyclerView.Adapter<listaPersonasAdapter.PersonaViewHolder> {

    ArrayList<Personas> listaPersonas;

    public listaPersonasAdapter(ArrayList<Personas> listaPersonas){
        this.listaPersonas = listaPersonas;
    }

    @NonNull
    @Override
    public PersonaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_item_persona, null,false);
        return new PersonaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonaViewHolder holder, int position) {
        holder.nombre.setText(listaPersonas.get(position).getNombre());
        holder.apellido.setText(listaPersonas.get(position).getApellido());
    }

    @Override
    public int getItemCount() {
        return listaPersonas.size();
    }

    public class PersonaViewHolder extends RecyclerView.ViewHolder {

        TextView nombre, apellido;
        public PersonaViewHolder(@NonNull View itemView) {
            super(itemView);

            nombre = itemView.findViewById(R.id.nombre);
            apellido = itemView.findViewById(R.id.apellido);
        }
    }
}
