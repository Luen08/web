package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.afinal.adapatadores.listaPersonasAdapter;
import com.example.afinal.db.DbPersonas;
import com.example.afinal.entidades.Personas;

import java.util.ArrayList;

public class Mostrar extends AppCompatActivity {
    RecyclerView listaPersonas;
    ArrayList <Personas> listaArrayPersonas;
    public void regresarPrincipal (View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);

        listaPersonas = findViewById(R.id.listaPersonas);
        listaPersonas.setLayoutManager(new LinearLayoutManager(this));
        DbPersonas dbPersonas = new DbPersonas(Mostrar.this);

        listaArrayPersonas = new ArrayList<>();

        listaPersonasAdapter adapter = new listaPersonasAdapter(dbPersonas.mostrarPersonas());

        listaPersonas.setAdapter(adapter);


    }
}