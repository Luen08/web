package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.afinal.db.DbPersonas;

import java.io.ByteArrayOutputStream;


public class Registrar extends AppCompatActivity {
    public void regresarPrincipal (View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    ImageView imagen;
    Spinner spinner1;

    EditText doc, nom, ape, coor, web;

    Button btnConfirmar;

    @SuppressLint("WrongThread")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        doc = (EditText)findViewById(R.id.nDoc);
        nom = (EditText)findViewById(R.id.name);
        ape = (EditText)findViewById(R.id.ape);
        coor = (EditText)findViewById(R.id.coor);
        web = (EditText)findViewById(R.id.web);
        spinner1 = (Spinner)findViewById(R.id.spinner);
        String [] opciones = {"DNI","PASAPORTE","OTRO"};
        ArrayAdapter <String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, opciones);
        spinner1.setAdapter(adapter);

        imagen = findViewById(R.id.imagenId);


        btnConfirmar = (Button) findViewById(R.id.btnConfirmar);

        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DbPersonas dbPersonas = new DbPersonas(Registrar.this);
                long id = dbPersonas.insertarPersona(spinner1.getSelectedItem().toString(),doc.getText().toString(), nom.getText().toString(), ape.getText().toString(), coor.getText().toString(), web.getText().toString(), imagen);

                if(id > 0){
                    Toast.makeText(Registrar.this, "REGISTRADO CORRECTAMENTE",Toast.LENGTH_LONG).show();
                    limpiar();
                }else{
                    Toast.makeText(Registrar.this, "ERROR AL GUARDAR REGISTRO",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void limpiar(){
        doc.setText("");
        nom.setText("");
        ape.setText("");
        coor.setText("");
        web.setText("");


    }


    public void subirImg(View view) {
        cargarImagen();
    }

    private void cargarImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        intent.setType("image/");
        startActivityForResult(Intent.createChooser(intent,"Seleccione la Aplicacion"),10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            Uri path = data.getData();
            imagen.setImageURI(path);
        }
    }
}