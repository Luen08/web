package com.example.afinal.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.widget.ImageView;


import androidx.annotation.Nullable;

import com.example.afinal.entidades.Personas;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;


public class DbPersonas extends DbHelper {

    Context context;
    public DbPersonas(@Nullable Context context) {
        super(context);
        this.context = context;

    }

    public long insertarPersona(String tipo, String numero_doc, String nombre, String apellido, String coordenadas, String web, ImageView foto) {
        long id = 0;




        try {
            foto.buildDrawingCache();
            Bitmap bitmap = foto.getDrawingCache();
            ByteArrayOutputStream baos = new ByteArrayOutputStream(2048000);
            bitmap.compress(Bitmap.CompressFormat.PNG, 0 , baos);
            byte[] blob = baos.toByteArray();


            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put("tipo_documento", tipo);
            values.put("numero_documento", numero_doc);
            values.put("nombre", nombre);
            values.put("apellido", apellido);
            values.put("coordenadas", coordenadas);
            values.put("sitio_web", web);
            values.put("fotografia", blob);

            id = db.insert(TABLE_PERSONA, null, values);

        } catch (Exception ex) {
            ex.toString();
        }

        return id;

    }

    public ArrayList<Personas> mostrarPersonas(){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<Personas> listaPersonas = new ArrayList<>();

        Personas persona = null;
        Cursor cursorPersonas = null;

        cursorPersonas = db.rawQuery("SELECT nombre, apellido FROM "+ TABLE_PERSONA,null);

        if(cursorPersonas.moveToFirst()){
            do{
                persona = new Personas();
                persona.setNombre(cursorPersonas.getString(3));
                persona.setApellido(cursorPersonas.getString(4));

                listaPersonas.add(persona);
            }while(cursorPersonas.moveToNext());
        }
        cursorPersonas.close();

        return listaPersonas;

    }
}

