$("#btnIngresar").click(function(){
    $("#username").val("");
    $("#password").val("");
});