<?php
    session_start();

    if(!isset($_SESSION['id_persona'])){
        header('location: ../logIn.php');
    
        session_destroy();
    
        die();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/styleGlobal.css">
    <link rel="stylesheet" href="../../css/styleActores.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <title>Actores</title>
</head>
<body class="yoMando">
    <?php

    $id = $_SESSION["id_persona"];

    $crud = "actores";

    include '../../include/conexion.php';
    $cn = ConexionMysql::Conectarse();

    if ($crud) {
        if ($crud == "actores") {
            $tabla = '';
            $tabla .=  '<table class="table pt-2" id="tbActores">
            <thead style="text-align: center ;">
                <tr class="thead">
                    <th class="thead--hover">Nombre</th>
                    <th class="thead--hover">Apellido</th>
                    <th class="thead--hover">País</th>
                    <th class="thead--hover">Año de nacimiento</th>
                    <th class="thead--hover">Pelicula</th>
                    <th class="thead--hover th-btn">OPCIONES</th>
                </tr>
            </thead>
            <tbody style="text-align: center;">';

            $vista = $cn->prepare("call sp_vista_actores();");
            $vista->execute();

            $visualizacion = $vista->fetchAll();
            foreach ($visualizacion as $fila) {
                $tabla .=             '<tr class="table-hover--bg">
                                        <td>' . $fila["actor_Nombre"] . '</td>
                                        <td>' . $fila["actor_Apellido"] . '</td>
                                        <td>' . $fila["actor_nacionalidad"] . '</td>
                                        <td>' . $fila["actor_Anio_nacimiento"] . '</td>
                                        <td>' . $fila["pelicula_titulo"] . '</td>
                                        <td><button id="' . $fila["actor_id"] . '" class="btn btn-color btn-xs UpdateActor"><i class="fa-solid fa-pen-to-square"></i></button>
                                        <button id="' . $fila["actor_id"] . '" class="btn btn-color--rojo btn-xd DeleteActor"><i class="fa-solid fa-trash"></i></button>
                                        </td>
                                    </tr>';
            }
            $tabla .= '</tbody></table>';
            $vista->closeCursor();
            $vista = null;
        }
    }

    ?>
<?php include("nav.html");?>
    <div class="title-cont">
        <div class="col-auto">
            <!-- Button -->
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#staticBackdrop" id="btnIngresarAct">
            </button>
        </div>
        <div class="title-text-cont">
            <h1 class="titulo">Actores</h1>
        </div>
    </div>

    <div class="container" id="vista_actores">
            <?php echo $tabla; ?>
    </div>

    <!--  MODAL  -->  
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Nombre: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtNombre" class="form-control"></input>
                        </div>
                            
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Apellido: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtApellido" class="form-control" ></input>
                        </div>
                            
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Año de nacimiento: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtAnio" class="form-control" ></input>
                        </div>
                            
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">País: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtPais" class="form-control" ></input>
                        </div>
                            
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Pelicula: </label>
                        <div class="col-sm-6">
                            <select class="form-select" name="txtPelicula" id="txtPelicula">
                                <option>Seleccionar una pelicula</option>
                            <?php
                                $buscar = $cn->prepare("call sp_listar_peliculas();");
                                $buscar->execute();
                                $resultado = $buscar->fetchAll();

                                foreach ($resultado as $row) {
                                    $id_pelicula = $row["pelicula_id"];
                                    $titulo = $row["pelicula_titulo"];
                            ?>
                                <option value="<?php echo $id_pelicula ?>"><?php echo $titulo; ?></option>
                            <?php
                            }
                            ?>
                            </select>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" id="btnInsertarActor"></button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title1" id="staticBackdropLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Nombre: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtNombre1" class="form-control"></input>
                        </div>
                            
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Apellido: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtApellido1" class="form-control" ></input>
                        </div>
                            
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Año de nacimiento: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtAnio1" class="form-control" ></input>
                        </div>
                            
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">País: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtPais1" class="form-control" ></input>
                            <input type="hidden" id="txtId1" class="form-control" ></input>
                        </div>
                            
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Pelicula: </label>
                        <div class="col-sm-6">
                            <select class="form-select" name="txtPelicula1" id="txtPelicula1">
                            <?php
                                $buscar = $cn->prepare("call sp_listar_peliculas();");
                                $buscar->execute();
                                $resultado = $buscar->fetchAll();

                                foreach ($resultado as $row) {
                                    $id_pelicula = $row["pelicula_id"];
                                    $titulo = $row["pelicula_titulo"];
                            ?>
                                <option value="<?php echo $id_pelicula ?>"><?php echo $titulo; ?></option>
                            <?php
                            }
                            ?>
                            </select>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success" id="btnActualizarActor"></button>
                </div>
            </div>
        </div>
    </div>

    <?php include("../../include/footer.php");?>
</body>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

</html>
<script src="../../js/actores.js" type="text/javascript"></script>