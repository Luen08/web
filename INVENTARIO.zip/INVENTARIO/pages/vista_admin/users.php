<?php
    session_start();

    if(!isset($_SESSION['id_persona'])){
        header('location: ../logIn.php');
    
        session_destroy();
    
        die();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/styleGlobal.css">
    <link rel="stylesheet" href="../../css/styleUsers.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <title>Comunidad</title>
</head>
<body class="yoMando">
    <?php

    $id = $_SESSION["id_persona"];

    $crud = "usuarios";

    include '../../include/conexion.php';
    $cn = ConexionMysql::Conectarse();

    if ($crud) {
        if ($crud == "usuarios") {
            $tabla = '';
            $tabla .=  '<table class="table pt-2" id="tbActores">
            <thead style="text-align: center ;">
                <tr class="thead">
                    <th class="thead--hover">Tipo</th>
                    <th class="thead--hover">Dni</th>
                    <th class="thead--hover">Nombres</th>
                    <th class="thead--hover">Apellido Paterno</th>
                    <th class="thead--hover">Apellido Materno</th>
                    <th class="thead--hover">Correo</th>
                    <th class="thead--hover">Contraseña</th>
                </tr>
            </thead>
            <tbody style="text-align: center;">';

            $vista = $cn->prepare("call sp_vista_users();");
            $vista->execute();

            $visualizacion = $vista->fetchAll();
            foreach ($visualizacion as $fila) {
                $tabla .=             '<tr class="table-hover--bg">
                                        <td>' . $fila["cargo_nombre"] . '</td>
                                        <td>' . $fila["persona_dni"] . '</td>
                                        <td>' . $fila["persona_Nombre"] . '</td>
                                        <td>' . $fila["persona_ApellidoPa"] . '</td>
                                        <td>' . $fila["persona_ApellidoMa"] . '</td>
                                        <td>' . $fila["persona_Correo"] . '</td>
                                        <td>' . $fila["usuario_contrasenia"] . '</td>
                                    </tr>';
            }
            $tabla .= '</tbody></table>';
            $vista->closeCursor();
            $vista = null;
        }
    }

    ?>
<?php include("nav.html");?>
    <div class="title-cont">
        <div class="title-text-cont">
            <h1 class="titulo"></h1>
        </div>
        <div class="title-text-cont">
            <h1 class="titulo">Usuarios</h1>
        </div>
    </div>

    <div class="container" id="vista_actores">
            <?php echo $tabla; ?>
    </div>

    
</body>
<?php include("../../include/footer.php");?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

</html>
<script src="../../js/actores.js" type="text/javascript"></script>