<?php
    session_start();

    if(!isset($_SESSION['id_persona'])){
        header('location: ../logIn.php');
    
        session_destroy();
    
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peliculas</title>
    <!-- STYLES -->
    <link rel="stylesheet" href="../../css/styleGlobal.css">
    <link rel="stylesheet" href="../../css/stylePeliculas.css">
    <!-- JQUERY -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- FONTAWESOME -->
    <script src="https://kit.fontawesome.com/54a24d044d.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.2.0/css/all.css" />
</head>
<body class="yoMando">
    <?php

    $id = $_SESSION["id_persona"];

    $crud = "pelis";

    include '../../include/conexion.php';
    $cn = ConexionMysql::Conectarse();
    if ($crud) {
        if ($crud == "pelis") {
            $tabla = '';
            $tabla .=  '<table class="table pt-2" id="tbPelis">
            <thead style="text-align: center ;">
                <tr class="thead">
                    <th class="thead--hover">Titulo</th>
                    <th class="thead--hover">Genero</th>
                    <th class="thead--hover">Valoracion</th>
                    <th class="thead--hover">Duracion</th>
                    <th class="thead--hover">Año de lanzamiento</th>
                    <th class="thead--hover">Imagen</th>
                    <th class="thead--hover">Video</th>
                    <th class="thead--hover th-btn">OPCIONES</th>
                </tr>
            </thead>
            <tbody style="text-align: center;">';
    
            $vista = $cn->prepare("call sp_vista_peliculas();");
            $vista->execute();
    
            $visualizacion = $vista->fetchAll();
            foreach ($visualizacion as $fila) {
                $tabla .=             '<tr class="table-hover--bg">
                                        <td>' . $fila["pelicula_titulo"] . '</td>
                                        <td>' . $fila["pelicula_genero"] . '</td>
                                        <td>' . $fila["pelicula_valoracion"] . '</td>
                                        <td>' . $fila["pelicula_duracion"] . '</td>
                                        <td>' . $fila["pelicula_anio"] . '</td>
                                        <td><a href="'.$fila["pelicula_link_image"]. '">Image</a></td>
                                        <td><a href="'.$fila["pelicula_link_video"]. '">Video</a></td>
                                        <td><button id="' . $fila["pelicula_id"] . '" class="btn btn-color btn-xs UpdatePeli"><i class="fa-solid fa-pen-to-square"></i></button>
                                        <button id="' . $fila["pelicula_id"] . '" class="btn btn-color--rojo btn-xd DeletePeli"><i class="fa-solid fa-trash"></i></button>
                                        </td>
                                        </tr>';
            }
            $tabla .= '</tbody></table>';
            $vista->closeCursor();
            $vista = null;
        }
    }
    

    ?>
    <?php include("nav.html");?>

    <div class="title-cont">
        <div class="col-auto">
            <button id="btnIngresarPeli" type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#formulario-modal-pelis">
                <i class="fa-solid fa-plus"></i>
            </button>
        </div>
        <div class="title-text-cont">
            <h1 class="titulo">Peliculas</h1>
        </div>
    </div>

    <div class="container" id="vista_pelis">
            <?php echo $tabla; ?>
    </div>

    <div id="formulario-modal-pelis" class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="tittle_pelis" id="pelis"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Movie title: </label>
                        <div class="col-sm-6">
                            <input type="text" id="txtTitleMovie" class="form-control" placeholder="Search">
                        </div>
                        <div class="col-sm-3" >
                            <button id="btnBuscarPeli" class="form-control btn btn-primary">Buscar</button>
                        </div>
                        
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Sinopsis: </label>
                        <div class="col-sm-9">
                            <textarea type="text" id="txtSinopsis" class="form-control" readonly></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Valoracion: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtValoracion" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Genero:</label>
                        <div class="col-sm-9">
                            <input type="text" id="txtGenero" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Duracion: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtDuracion" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Año: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtAnio" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Link de imagen: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtLinkImage" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Link de video: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtLinkVideo" class="form-control">
                        </div>
                    </div>

                    <div class="form-group row hidden-cont">
                        <div class="col-sm-4">
                            <input type="hidden" id="crud" class="form-control" value="pelis">
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
                    <button id="btnActionPeli" type="button" class="btn btn-success"></button>
                </div>
            </div>
        </div>
    </div>

    <div id="formulario-modal-actualizar-pelis" class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="tittle_actualizar_pelis" id="pelis"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Titulo: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtTitulo1" class="form-control" >
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Sinopsis: </label>
                        <div class="col-sm-9">
                            <textarea type="text" id="txtSinopsis1" class="form-control" ></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Valoracion: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtValoracion1" class="form-control" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Genero:</label>
                        <div class="col-sm-9">
                            <input type="text" id="txtGenero1" class="form-control" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Duracion: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtDuracion1" class="form-control" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Año: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtAnio1" class="form-control" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Link de imagen: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtLinkImage1" class="form-control" >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Link de video: </label>
                        <div class="col-sm-9">
                            <input type="text" id="txtLinkVideo1" class="form-control">
                        </div>
                    </div>

                    <div class="form-group row hidden-cont">
                        <div class="col-sm-4">
                            <input type="hidden" id="crud" class="form-control" value="pelis">
                            <input type="hidden" id="txtId1" class="form-control">
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
                    <button id="btnActionActualizarPeli" type="button" class="btn btn-success"></button>
                </div>
            </div>
        </div>
    </div>

    <?php include("../../include/footer.php");?>
</body>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

</html>
<script src="../../js/peliculas.js" type="text/javascript"></script>