<?php 
session_start();

if(!isset($_SESSION['id_persona'])){
    header('location: ../logIn.php');

    session_destroy();

    die();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" href="../../css/styleHome.css" rel="stylesheet">
    <title>Inicio</title>
</head>
<body>
<?php 

    include '../../include/conexion.php';
    $id = $_SESSION["id_persona"];
    $cn = ConexionMysql::Conectarse();

    ?>

    <?php
    $buscar = $cn->prepare("call sp_contar_peliculas;");
    $buscar->execute();

    $busqueda = $buscar->fetchAll();

    foreach ($busqueda as $fila) {
        $cantPelis = $fila["count(*)"];
    }
    $buscar->closeCursor();
    $buscar = null;
    $busqueda = null;

?>

<?php
    $buscar = $cn->prepare("call sp_contar_actores;");
    $buscar->execute();

    $busqueda = $buscar->fetchAll();

    foreach ($busqueda as $fila) {
        $cantAct = $fila["count(*)"];
    }
    $buscar->closeCursor();
    $buscar = null;
    $busqueda = null;

?>

<?php
    $buscar = $cn->prepare("call sp_contar_directores;");
    $buscar->execute();

    $busqueda = $buscar->fetchAll();

    foreach ($busqueda as $fila) {
        $cantDirec = $fila["count(*)"];
    }
    $buscar->closeCursor();
    $buscar = null;
    $busqueda = null;

?>

<?php
    $buscar = $cn->prepare("call sp_contar_productores;");
    $buscar->execute();

    $busqueda = $buscar->fetchAll();

    foreach ($busqueda as $fila) {
        $cantProd = $fila["count(*)"];
    }
    $buscar->closeCursor();
    $buscar = null;
    $busqueda = null;

?>
    <!-- BARRA DE NAVEGACION -->
    <?php include("nav.html"); ?>

    <div class="contenedor_t">
        <h2 class="AD_US">Bienvenido "administrador" <?php echo $_SESSION['Nombres'] . " " . $_SESSION['ApellidoPaterno'] . " " . substr($_SESSION['ApellidoMaterno'], 0, 1) . "."; ?></h2>
    </div>

    <div class="contenedor">
        <h2 class="sub">Sistema Cinema Info Backend</h2>
    </div>

    <!-- cuadro Usuarios-->
    <div class="cuadros">
        <!--  cuadro Usuarios-->
        <div class="cuadros_1">

            <div class="icono">
                <a href="peliculas.php">
                    <img src="../../img/icoPeli.png"></img>
                </a>
            </div>

            <div class="cuadros_secundario">
                <span><?php echo $cantPelis; ?></span>
                <p>Peliculas</p>
            </div>
        </div>

        <!--  cuadro categoria-->
        <div class="cuadros_1">

            <div class="icono">
                <a href="actores.php">
                    <img src="../../img/icoAct.png"></img>
                </a>
            </div>

            <div class="cuadros_secundario">
                <span><?php echo $cantAct; ?></span>
                <p>Actores</p>
            </div>
        </div>

        <!--  cuadro productos-->
        <div class="cuadros_1">

            <div class="icono">
                <a href="directores.php">
                    <img src="../../img/icoDire.png"></img>
                </a>
            </div>
            <div class="cuadros_secundario">
                <span><?php echo $cantDirec; ?></span>
                <p>Directores</p>
            </div>
        </div>

        <!--  cuadro Productores-->
        <div class="cuadros_1">

            <div class="icono">
                <a href="productores.php">
                    <img src="../../img/icoProd.png"></img>
                </a>
            </div>
            <div class="cuadros_secundario">
                <span><?php echo $cantProd; ?></span>
                <p>Productores</p>
            </div>
        </div>
    </div>
    <br>
    <?php include("../../include/footer.php");?>
    
</body>
</html>