<?php
    session_start();

    if(!isset($_SESSION['id_persona'])){
        header('location: ../logIn.php');
    
        session_destroy();
    
        die();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/styleVistaUsuario.css">
    <title>Peliculas</title>
</head>
<body>
<?php
    $id = $_SESSION["id_persona"];

    $crud = "inicio";

    include '../../include/conexion.php';
    $cn = ConexionMysql::Conectarse();

    if ($crud) {
        if ($crud == "inicio") {
            $vista = $cn->prepare("call sp_vista_peliculas();");
            $vista->execute();

            $visualizacion = $vista->fetchAll();
            $vista->closeCursor();
            $vista = null;
        }
    }

    ?>
    <?php include("nav.html");?>
    <main>
        <div class="contenedor">
            <?php 
                for($i=0; $i<sizeof($visualizacion);$i++){
                    ?>
                    <div class="card">
                        <a class="box-img" href="request.php?pel=<?php echo($visualizacion[$i]["pelicula_id"]);?>">
                            <img class="imagen" src='<?php echo($visualizacion[$i]["pelicula_link_image"]);?>'>
                        </a>
                        
                        <label><?php echo($visualizacion[$i]["pelicula_titulo"]);?></label>
                    </div>
                    <?php
                }
            ?>
        </div>
    </main>
</body>
<?php include("../../include/footer.php")?>
</html>