<?php
session_start();

if(!isset($_SESSION['id_persona'])){
    header('location: ../logIn.php');

    session_destroy();

    die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/54a24d044d.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/styleRequest.css">
    <title>Request</title>
</head>
<body>
    <?php

    $id_peli = $_GET["pel"];

    $id = $_SESSION["id_persona"];

    $crud = "request";

    include '../../include/conexion.php';
    $cn = ConexionMysql::Conectarse();
    if ($crud) {
        if ($crud == "request") {
            $vista = $cn->prepare("call sp_search_pelicula(:dato1);");
            $vista->bindParam(":dato1", $id_peli);
            $vista->execute();

            $visualizacion = $vista->fetchAll();
            foreach ($visualizacion as $fila) {
                $title = $fila["pelicula_titulo"];
                $plot = $fila["pelicula_sinopsis"];
                $rat = $fila["pelicula_valoracion"];
                $genr = $fila["pelicula_genero"];
                $time = $fila["pelicula_duracion"];
                $year = $fila["pelicula_anio"];
                $poster = $fila["pelicula_link_image"];
                $video = $fila["pelicula_link_video"];
            }
            $vista->closeCursor();
            $vista = null;
        }
    }


    ?>
    <?php include("nav.html");?>
    <div class="cuadros">
        <div class="cuadros_1">

            <div class="icono">
                <a href="<?php echo $video; ?>"><img src="<?php echo $poster;?>" alt="<?php echo $title;?>"></a>
                
            </div>

            <div class="cuadros_secundario">
                <h1><?php echo $title;?></h1>
                <span><?php echo $year;?></span>
                <p><?php echo $plot;?></p>
                <ul>
                    <li class="sub">
                        <strong>Generos:</strong>
                        <span><?php echo $genr;?></span>
                    </li>
                    <li class="sub">
                        <strong>Valoracion: </strong>
                        <span><?php echo $rat;?><i class="fa-solid fa-star"></i></span>
                    </li>
                    <li class="sub">
                        <strong>Duracion: </strong>
                        <span><?php echo $time;?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <?php include("../../include/footer.php")?>
</body>
</html>