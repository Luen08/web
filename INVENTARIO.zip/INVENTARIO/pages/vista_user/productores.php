<?php
session_start();

if(!isset($_SESSION['id_persona'])){
    header('location: ../logIn.php');

    session_destroy();

    die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/styleGlobal.css">
    <link rel="stylesheet" href="../../css/styleDirectores.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Productores</title>
</head>
<body class="yoMando">
    <?php

    $id = $_SESSION["id_persona"];

    $crud = "actores";

    include '../../include/conexion.php';
    $cn = ConexionMysql::Conectarse();

    if ($crud) {
        if ($crud == "actores") {
            $tabla = '';
            $tabla .=  '<table class="table pt-2" id="tb">
            <thead style="text-align: center ;">
                <tr class="thead">
                    <th class="thead--hover">Nombre</th>
                    <th class="thead--hover">Apellido</th>
                    <th class="thead--hover">País</th>
                    <th class="thead--hover">Año de nacimiento</th>
                    <th class="thead--hover">Pelicula</th>
                
                </tr>
            </thead>
            <tbody style="text-align: center;">';

            $vista = $cn->prepare("call sp_vista_productores();");
            $vista->execute();

            $visualizacion = $vista->fetchAll();
            foreach ($visualizacion as $fila) {
                $tabla .=             '<tr class="table-hover--bg">
                                        <td>' . $fila["actor_Nombre"] . '</td>
                                        <td>' . $fila["actor_Apellido"] . '</td>
                                        <td>' . $fila["actor_nacionalidad"] . '</td>
                                        <td>' . $fila["actor_Anio_nacimiento"] . '</td>
                                        <td>' . $fila["pelicula_titulo"] . '</td>
                                    </tr>';
            }
            $tabla .= '</tbody></table>';
            $vista->closeCursor();
            $vista = null;
        }
    }

    ?>
<?php include("nav.html");?>
    <div class="title-cont">
        <div class="col-auto">
            <!-- Button -->
            <a type="hidden"></a>
            
        </div>
        <div class="title-text-cont">
            <h1 class="titulo">Productores</h1>
        </div>
    </div>

    <div class="container" id="vista_actores">
            <?php echo $tabla; ?>
    </div>

    
</body>
<?php include("../../include/footer.php");?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

</html>
<script src="../../js/usuario.js"></script>