<?php
    require_once("../include/conexion.php");
    include_once("../include/user_session.php");

    $cn = ConexionMysql::Conectarse();

    $usuarioSession = new usuarioSession();

    if(isset($_POST["iniciar"])){
        // hay sesion
        if(isset($_POST["username"]) && isset($_POST["password"])){
            $usuario = $_POST["username"];
            $password = $_POST["password"];

            $buscar = $cn->prepare("call sp_search_usuario(:dato1);");
            $buscar->bindParam(":dato1", $usuario);
            $buscar->execute();

            $res = $buscar->fetchAll();

            foreach ($res as $fila) {
                if(isset($fila["usuario_contrasenia"])){
                    $contraseña = $_SESSION["contrasenia"] = $fila['usuario_contrasenia'];
                    $persona_id = $_SESSION["id_persona"] = $fila["persona_id"];
                    $cargo_id = $_SESSION["cargo"] =$fila["cargo_id"];
                    
                }else{
                    $contraseña = '';
                }
            }

            $buscar->closeCursor();
            $buscar = null;

            $buscar = $cn->prepare("call sp_search_persona(:dato1);");
            $buscar->bindParam(":dato1", $persona_id);
            $buscar->execute();

            $res = $buscar->fetchAll();

            foreach ($res as $fila) {
                $_SESSION["Dni"] = $fila["persona_dni"];
                $_SESSION["Nombres"] = $fila["persona_Nombre"];
                $_SESSION["ApellidoPaterno"] = $fila["persona_ApellidoPa"];
                $_SESSION["ApellidoMaterno"] = $fila["persona_ApellidoMa"];
                $_SESSION["Correo"] = $fila["persona_correo"];
            }

            $buscar->closeCursor();
            $buscar = null;



            if(isset($contraseña)){
                if($contraseña == $password){
                    //entra

                    if($cargo_id == 1){
                        header("location: vista_admin/home.php");
                    }elseif($cargo_id == 2){
                        header("location: vista_user/index.html");
                    }

                    
                }else{
                    echo "contraseña incorrecta";
                }
            }else{
                echo "usuario no encontrado";
            }

        }else{
            echo "DATOS VACIOS";
            include_once("login.php");
        }
    }else{
        header("location: logIn.php");
    }
?>