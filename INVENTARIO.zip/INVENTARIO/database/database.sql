-- procedimientos almacenados
use cinema;
drop procedure if exists sp_insertar_persona;
DELIMITER ;;
create procedure sp_insertar_persona
(
in 
	dni varchar(8),
    nombre varchar(80),
    apellidopa varchar(50),
    apellidoma varchar(50),
    correo varchar(70)
)
begin
	insert into persona(persona_dni, persona_Nombre, persona_ApellidoPa, persona_ApellidoMa, persona_Correo) values(dni,nombre,apellidopa,apellidoma,correo);
end;;
DELIMITER ;



drop procedure if exists sp_update_persona;
DELIMITER ;;
create procedure sp_update_persona
(
in 
	id int,
    correo varchar(70)
)
begin
	update persona set persona_Correo = correo where persona_id = id;
end;;
DELIMITER ;

drop procedure if exists sp_vista_persona;
DELIMITER ;;
create procedure sp_vista_persona
(
)
begin
	select * from persona;
end;;
DELIMITER ;

drop procedure if exists sp_search_persona;
DELIMITER ;;
create procedure sp_search_persona
(
	id int
)
begin
	select * from persona where persona_id = id;
end;;
DELIMITER ;

drop procedure if exists sp_insertar_usuario;
DELIMITER ;;
create procedure sp_insertar_usuario
(
	persona_id int,
    correo varchar(70),
    contrasenia varchar(50)
)
begin
	insert into usuario(persona_id, usuario_correo, usuario_contrasenia, cargo_id) values(persona_id,correo,contrasenia,2);
end;;
DELIMITER ;

drop procedure if exists sp_insertar_admin;
DELIMITER ;;
create procedure sp_insertar_admin
(
	persona_id int,
    correo varchar(70),
    contrasenia varchar(50)
)
begin
	insert into usuario(persona_id, usuario_correo, usuario_contrasenia, cargo_id) values(persona_id,correo,contrasenia,1);
end;;
DELIMITER ;

drop procedure if exists sp_update_usuario;
DELIMITER ;;
create procedure sp_update_usuario
(
	usu_id int,
    contrasenia varchar(50)
)
begin
	update usuario set usuario_contrasenia = contrasenia where usuario_id = usu_id ;
end;;
DELIMITER ;

drop procedure if exists sp_search_usuario;
DELIMITER ;;
create procedure sp_search_usuario
(
	correo varchar(70)
)
begin
	select * from usuario where usuario_correo = correo;
end;;
DELIMITER ;

drop procedure if exists sp_search_persona_dni;
DELIMITER ;;
create procedure sp_search_persona_dni
(
	Dni int
)
begin
	select persona_id from persona where persona_dni = Dni;
end;;
DELIMITER ;

drop procedure if exists sp_contar_peliculas;
DELIMITER ;;
create procedure sp_contar_peliculas
(
	
)
begin
	select count(*) from pelicula;
end;;
DELIMITER ;

drop procedure if exists sp_contar_actores;
DELIMITER ;;
create procedure sp_contar_actores
(
	
)
begin
	select count(*) from actor;
end;;
DELIMITER ;


drop procedure if exists sp_contar_directores;
DELIMITER ;;
create procedure sp_contar_directores
(
	
)
begin
	select count(*) from director;
end;;
DELIMITER ;


drop procedure if exists sp_contar_productores;
DELIMITER ;;
create procedure sp_contar_productores
(
	
)
begin
	select count(*) from productor;
end;;
DELIMITER ;



drop procedure if exists sp_insertar_peliculas;
DELIMITER ;;
create procedure sp_insertar_peliculas
(
	title varchar(50),
    plot varchar(250),
    rat varchar(15),
    genr varchar(70),
    taime varchar(10),
    yiar varchar(15),
    url_image varchar(250),
    url_video varchar(250)
)
begin
	insert into pelicula(pelicula_titulo,pelicula_sinopsis,pelicula_valoracion,pelicula_genero,pelicula_duracion,pelicula_anio,pelicula_link_image,pelicula_link_video)values(title,plot,rat,genr,taime,yiar,url_image,url_video);
end;;
DELIMITER ;

drop procedure if exists sp_update_peliculas;
DELIMITER ;;
create procedure sp_update_peliculas
(
	pel_id int,
	title varchar(50),
    plot varchar(250),
    rat varchar(15),
    genr varchar(70),
    taime varchar(10),
    yiar varchar(15),
    url_image varchar(250),
    url_video varchar(250)
)
begin
	update pelicula set pelicula_titulo = title, pelicula_sinopsis = plot, pelicula_valoracion = rat, pelicula_genero = genr, pelicula_duracion=taime, pelicula_anio = yiar, pelicula_link_image = url_image, pelicula_link_video = url_video where pelicula_id = pel_id;
end;;
DELIMITER ;

drop procedure if exists sp_delete_peliculas;
DELIMITER ;;
create procedure sp_delete_peliculas
(
	pel_id int
)
begin
	delete from pelicula where pelicula_id = pel_id;
end;;
DELIMITER ;


drop procedure if exists sp_insertar_actores;
DELIMITER ;;
create procedure sp_insertar_actores
(
	nombre varchar(20),
    apellido varchar(25),
    anio_nacimiento varchar(4),
    pais varchar(15),
    pel_id int
)
begin
	insert into actor(actor_Nombre,actor_Apellido,actor_Anio_nacimiento,actor_nacionalidad,pelicula_id)values(nombre,apellido,anio_nacimiento,pais,pel_id);
end;;
DELIMITER ;

drop procedure if exists sp_update_actores;
DELIMITER ;;
create procedure sp_update_actores
(
	act_id int,
	nombre varchar(20),
    apellido varchar(25),
    anio_nacimiento varchar(4),
    pais varchar(15),
    pel_id int
)
begin
	update actor set actor_Nombre = nombre, actor_Apellido = apellido, actor_Anio_nacimiento = anio_nacimiento, actor_nacionalidad = pais, pelicula_id=pel_id where actor_id = act_id;
end;;
DELIMITER ;

drop procedure if exists sp_delete_actores;
DELIMITER ;;
create procedure sp_delete_actores
(
	act_id int
)
begin
	delete from actor where actor_id = act_id;
end;;
DELIMITER ;


drop procedure if exists sp_insertar_productores;
DELIMITER ;;
create procedure sp_insertar_productores
(
	nombre varchar(20),
    apellido varchar(25),
    anio_nacimiento varchar(4),
    pais varchar(15),
    pel_id int
)
begin
	insert into productor(productor_Nombre,productor_Apellido,productor_Anio_nacimiento,productor_nacionalidad,pelicula_id)values(nombre,apellido,anio_nacimiento,pais,pel_id);
end;;
DELIMITER ;

drop procedure if exists sp_update_productores;
DELIMITER ;;
create procedure sp_update_productores
(
	prod_id int,
	nombre varchar(20),
    apellido varchar(25),
    anio_nacimiento varchar(4),
    pais varchar(15),
    pel_id int
)
begin
	update productor set productor_Nombre = nombre, productor_Apellido = apellido, productor_Anio_nacimiento = anio_nacimiento, productor_nacionalidad = pais, pelicula_id=pel_id where productor_id = prod_id;
end;;
DELIMITER ;

drop procedure if exists sp_delete_productores;
DELIMITER ;;
create procedure sp_delete_productores
(
	prod_id int
)
begin
	delete from productor where productor_id = prod_id;
end;;
DELIMITER ;

-- aqui

drop procedure if exists sp_insertar_directores;
DELIMITER ;;
create procedure sp_insertar_directores
(
	nombre varchar(20),
    apellido varchar(25),
    anio_nacimiento varchar(4),
    pais varchar(15),
    pel_id int
)
begin
	insert into director(director_Nombre,director_Apellido,director_Anio_nacimiento,director_nacionalidad,pelicula_id)values(nombre,apellido,anio_nacimiento,pais,pel_id);
end;;
DELIMITER ;

drop procedure if exists sp_update_directores;
DELIMITER ;;
create procedure sp_update_directores
(
	direc_id int,
	nombre varchar(20),
    apellido varchar(25),
    anio_nacimiento varchar(4),
    pais varchar(15),
    pel_id int
)
begin
	update director set director_Nombre = nombre, director_Apellido = apellido, director_Anio_nacimiento = anio_nacimiento, director_nacionalidad = pais, pelicula_id=pel_id where director_id = direc_id;
end;;
DELIMITER ;

drop procedure if exists sp_delete_directores;
DELIMITER ;;
create procedure sp_delete_directores
(
	direc_id int
)
begin
	delete from director where director_id = direc_id;
end;;
DELIMITER ;

drop procedure if exists sp_listar_peliculas;
DELIMITER ;;
create procedure sp_listar_peliculas
(
)
begin
	select pelicula_id, pelicula_titulo from pelicula;
end;;
DELIMITER ;

drop procedure if exists sp_vista_peliculas;
DELIMITER ;;
create procedure sp_vista_peliculas
(
)
begin
	SELECT *
	FROM pelicula;
end;;
DELIMITER ;

drop procedure if exists sp_vista_actores;
DELIMITER ;;
create procedure sp_vista_actores
(
)
begin
	SELECT *
	FROM actor 
	INNER JOIN pelicula ON actor.pelicula_id = pelicula.pelicula_id;
end;;
DELIMITER ;

drop procedure if exists sp_vista_directores;
DELIMITER ;;
create procedure sp_vista_directores
(
)
begin
	SELECT *
	FROM director 
	INNER JOIN pelicula ON director.pelicula_id = pelicula.pelicula_id;
end;;
DELIMITER ;

drop procedure if exists sp_vista_productores;
DELIMITER ;;
create procedure sp_vista_productores
(
)
begin
	SELECT *
	FROM productor 
	INNER JOIN pelicula ON productor.pelicula_id = pelicula.pelicula_id;
end;;
DELIMITER ;

drop procedure if exists sp_vista_users;
DELIMITER ;;
create procedure sp_vista_users
(
)
begin
	SELECT *
	FROM persona 
	INNER JOIN usuario ON persona.persona_id = usuario.persona_id
    INNER JOIN cargo ON usuario.cargo_id = cargo.cargo_id;
end;;
DELIMITER ;

drop procedure if exists sp_search_pelicula;
DELIMITER ;;
create procedure sp_search_pelicula
(
	id int
)
begin
	select * from pelicula where pelicula_id = id;
end;;
DELIMITER ;

drop procedure if exists sp_search_actor;
DELIMITER ;;
create procedure sp_search_actor
(
	id int
)
begin
	select * from actor where actor_id = id;
end;;
DELIMITER ;

drop procedure if exists sp_search_director;
DELIMITER ;;
create procedure sp_search_director
(
	id int
)
begin
	select * from director where director_id = id;
end;;
DELIMITER ;

drop procedure if exists sp_search_productor;
DELIMITER ;;
create procedure sp_search_productor
(
	id int
)
begin
	select * from productor where productor_id = id;
end;;
DELIMITER ;
select * from usuario

insert into cargo(cargo_nombre) values("Admin");
insert into cargo(cargo_nombre) values("User");
call sp_insertar_persona("74229472","LUIS ENRIQUE","CONDORI","GOICOCHEA","Admin");
call sp_insertar_admin(1,"Admin","Admin");