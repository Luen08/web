<?php
class ConexionMysql
{
	static $Servidor = "cinemainfo.mysql.database.azure.com";
	static $Puerto = "3306";
	static $BaseDatos = "cinema";
	static $Usuario = "Administrador";
	static $Password = "Cjoxvwdk222";
	
	function __construct()
	{
	
	}

	static function Conectarse(){
		try{

			$cn = new PDO("mysql:host=".self::$Servidor.";port=".self::$Puerto.";dbname=".self::$BaseDatos, self::$Usuario, self::$Password);
            return $cn;

		}catch(PDOException $e){
            echo $e;
			return null;
		}
	}
}
?>