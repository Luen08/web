<?php 
    require_once "user_session.php";

    $usuarioSession= new UsuarioSession();
    $usuarioSession->cerrarSession();
    
    header("location: ../pages/index.php");

?>

