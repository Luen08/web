<?php
/**
 * 
 */
class ConexionMysql
{
	static $Servidor = "localhost";
	static $Puerto = "3306";
	static $BaseDatos = "DBproyecto";
	static $Usuario = "root";
	static $Password = "cjoxvwdk222";
	
	function __construct()
	{
	
	}

	static function Conectarse(){
		try{
			$cn = new PDO("mysql:host=".self::$Servidor.";port=".self::$Puerto.";dbname=".self::$BaseDatos, self::$Usuario, self::$Password);
			return $cn;

		}catch(PDOException $e){
			echo "Error en la conexion";
			return null;
		}
	}
}


?>