<?php

include'conexion.php';
$cn = ConexionMysql::Conectarse();

if (isset($_POST["crud"])) {

	if($_POST['crud'] == "Vista"){
		$tabla = '';
		$tabla .= '<table class="table table-hover" style="margin-top: 20px;" id="tbVista">
										<thead style="text-align: center ;">
											<tr>
												<th>id</th>
												<th>Nombres</th>
												<th>Apellidos</th>
												<th>Edad</th>
												<th>Email</th>
												<th>Carrera</th>
												<th>Semestre</th>
												<th>Curso</th>
												<th>Valoracion</th>
												<th colspan="2">Configurar</th>
											</tr>
										</thead>
										<tbody style="text-align: center;">';
							
		$vista = $cn->prepare('call spVistaProfesores();');
		$vista->execute();

		$visualizacion = $vista->fetchAll();

		foreach ($visualizacion as $fila) {
			$tabla.= 			'<tr>
											<td>'.$fila["id"].'</td>
											<td>'.$fila["Nombre"].'</td>
											<td>'.$fila["Apellidos"].'</td>
											
											<td>'.$fila["Edad"].'</td>
											<td>'.$fila["Email"].'</td>
											<td>'.$fila["Carrera"].'</td>
											<td>'.$fila["Semestre"].'</td>
											<td>'.$fila["Curso"].'</td>
											<td>'.$fila["Valoracion"].'</td>
											<td>
												<button id="'.$fila["id"].'" class="btn btn-warning btn-xs actualizar">Editar</button>
											</td>
											<td>
												<button id="'.$fila["id"].'" class="btn btn-danger btn-xs delete">Eliminar</button>
											</td>
										</tr>';

			}
			$tabla .= '</tbody></table>';
			echo $tabla;
	}

	if ($_POST["crud"] == "Insertar") {

		$insertar = $cn->prepare("call spInsertarProfesores(:dato1, :dato2, :dato3, :dato4, :dato5, :dato6, :dato7, :dato8, :dato9);");
		$insertar->bindParam(':dato1',$_POST["Nom"]);
		$insertar->bindParam(':dato2',$_POST["Ape"]);
		$insertar->bindParam(':dato3',$_POST["Fnac"]);
		$insertar->bindParam(':dato4',$_POST["Email"]);
		$insertar->bindParam(':dato5',$_POST["Carre"]);
		$insertar->bindParam(':dato6',$_POST["Seme"]);
		$insertar->bindParam(':dato7',$_POST["Curso"]);
		$insertar->bindParam(':dato8',$_POST["Valo"]);
		$insertar->bindParam(':dato9',$_POST["Grado"]);
		
		try {
			$rpta = $insertar->execute();
			echo'Registro Insertado';
		} catch (PDOException $e) {
			echo'Error no se inserto';
		}
	}

	if ($_POST["crud"] == "Buscar"){

		$buscar = $cn->prepare('call spBuscarId(:dato1);');
		$buscar->bindParam(':dato1', $_POST['Id']);
		$buscar->execute();
		$resultado = $buscar->fetch();
		echo json_encode($resultado);
	}

	if ($_POST["crud"] == "Actualizar") {
		$actualizar = $cn->prepare("call spEditarProfesores(:dato1, :dato2, :dato3, :dato4, :dato5, :dato6, :dato7, :dato8, :dato9, :dato10);");
		$actualizar->bindParam(':dato1',$_POST["Id"]);
		$actualizar->bindParam(':dato2',$_POST["Nom"]);
		$actualizar->bindParam(':dato3',$_POST["Ape"]);
		$actualizar->bindParam(':dato4',$_POST["Fnac"]);
		$actualizar->bindParam(':dato5',$_POST["Email"]);
		$actualizar->bindParam(':dato6',$_POST["Carre"]);
		$actualizar->bindParam(':dato7',$_POST["Seme"]);
		$actualizar->bindParam(':dato8',$_POST["Curso"]);
		$actualizar->bindParam(':dato9',$_POST["Valo"]);
		$actualizar->bindParam(':dato10',$_POST["Grado"]);
		
		try{
			$rpta = $actualizar->execute();
			echo'Registro Actualizado';
		}catch(PDOException $e){
			echo 'Registro no actualizado';
		}
	}

	if ($_POST['crud'] == "Eliminar") {
			$delete = $cn->prepare("call spEliminarProfesores(:dato1);");
			$delete->bindParam(':dato1',$_POST['Id']);
			
			try {
				$rpta = $delete->execute();
				echo "Registro Eliminado";
				
			} catch (PDOException $e) {
				echo "Registro no eliminado";
			}
	}

	if ($_POST['crud'] == "Ingresar"){
		$buscar = $cn->prepare("call spBuscar(:dato1);");
		$buscar->bindParam(':dato1',$_POST['Username']);
		$buscar->execute();
		$resultado = $buscar->fetchAll();
		foreach ($resultado as $fila) {
			if(isset($fila['Contraseña'])){
				$contraseña = $fila['Contraseña'];
			}else{
				$contraseña = '';
			}
		}

		if (isset($contraseña)){
			if($contraseña == $_POST['Password']){
				echo'Confirmado'; // Redireccionar a la pagina

			}else{
				echo 'Contraseña Incorrecta'; // Contraseña incorrecta
			}
			
		}else{
			echo 'No existe su correo, ingrese otro o registrese'; // si no existe presentar solicitud para que ingrese
		}
	}

	if ($_POST['crud'] == "Registro"){
		$registrar = $cn->prepare("call spInsertarUsuario(:dato1, :dato2);");
		$registrar->bindParam('dato1', $_POST['CorreoRegistro']);
		$registrar->bindParam('dato2', $_POST['ContraseñaRegistro']);

		try {
			$rpta = $registrar->execute();
			echo 'Usuario Registrado';
		} catch (PDOException $e) {
			echo 'Correo Invalido';
		}
	}
}


?>