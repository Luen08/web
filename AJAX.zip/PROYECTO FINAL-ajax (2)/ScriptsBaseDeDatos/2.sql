-- FUNCION DE EDAD
-- COMANDO
SET GLOBAL log_bin_trust_function_creators = 1;
use dbproyecto;
drop FUNCTION if exists FnEdad;
delimiter //
create FUNCTION FnEdad(FechaNacimiento date) returns int
begin 
	Declare EDAD int;
	SET EDAD = timestampdiff(YEAR,FechaNacimiento,CURDATE());
    return EDAD;
end //
delimiter ;

SELECT *, FnEdad(FechaNacimiento) AS EDAD FROM Profesores;

-- FILTROS
-- PROCEDIMIENTOS ALMACENADOS
-- FILTRO GRADO BACHILLER
use dbproyecto;
drop procedure if exists spFiltroGradoB;
delimiter //
create procedure spFiltroGradoB()
begin 
	select * from profesores where Grado = 'Bachiller';
end //
delimiter ;

call spFiltroGradoB();

-- FILTRO GRADO TECNICO
use dbproyecto;
drop procedure if exists spFiltroGradoT;
delimiter //
create procedure spFiltroGradoT()
begin 
	select * from profesores where Grado = 'Tecnico';
end //
delimiter ;

call spFiltroGradoT();

-- FILTRO DE VALORACION 
-- FILTRO DE SEMESTRE