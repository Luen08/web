-- CREAR BASE DE DATOS, TABLAS
-- INSERTAR DATOS

drop database if exists DBproyecto;
create database DBproyecto;
SET @FECHA = curdate();
use DBproyecto;

drop table if exists Profesores;
create table Profesores
(
	id int auto_increment not null,
	Nombre Varchar(50) not null,
	Apellidos varchar(50) not null,
	FechaNacimiento date not null, -- No debe ser mayor a la fecha actual
	Edad int null, -- La edad se debe generar automaticamente  (Funcion)
    Email varchar(100) CHECK (Email like '%_@_%._%') not null, -- Validar con el formato x@xx.xx/x@x.xxx/x@x.xxx.xx
    Carrera varchar(50) not null,
	Semestre int CHECK (Semestre <= 10 and Semestre > 0) not null,
    Curso varchar(50) not null,
    Valoracion int CHECK(Valoracion <= 5 and Valoracion >= 0) not null,
    Grado varchar(50) not null,
    primary key(id)
);

insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
values('Luis','Condori','2004-03-08',FnEdad(FechaNacimiento),'LCondori@gmail.com','Ing. Sistemas',3,'Fundamentos de programación web',5,'Bachiller');

insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
values('Drussila','Aranda','2004-04-17',FnEdad(FechaNacimiento),'DAranda@gmail.com','Ing. Industrial',4,'Calculo de una variable',4,'Bachiller');

insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
values('Lizeth','Gomez','2004-02-28',FnEdad(FechaNacimiento),'LGomez@gmail.com','Psicologia',5,'Estudio de la mente',5,'Bachiller');

insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
values('Eduardo','Soto','2004-02-28',FnEdad(FechaNacimiento),'ESoto@gmail.com','Barberia',6,'Estudio de la mente',2,'Tecnico');

insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
values('Ximena','Quesada','2002-03-27',FnEdad(FechaNacimiento),'XQuesada@gmail.com','Desarrollo de software',1,'Software Aplicativo',3,'Bachiller');

insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
values('Marzio','Fernandez','2004-03-13',FnEdad(FechaNacimiento),'MFernandez@gmail.com','Contabilidad',2,'Excel basico',4,'Bachiller');

insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
values('Fernando','Paco','2002-08-27',FnEdad(FechaNacimiento),'FPaco@gmail.com','Ciberseguridad',6,'Fundamentos de seguridad informática',3,'Tecnico');

select * from Profesores;

drop table if exists Usuarios;
create table Usuarios
(
	Email varchar(100) CHECK (Email like '%_@_%._%') not null,
    Contraseña varchar(100) not null,
    primary key(Email)
);


