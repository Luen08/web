$(document).ready(function(){
	Vista();
	function Vista(){
		let op = "Vista";
		$.ajax({
			url:'procesos.php',
			method:'POST',
			data:{crud: op},
			success:function(data){

				$('#resultado').html(data);
				

			}
		});

	}

	$('#btnmodal').click(function(){
		$('#formulario-modal').modal('show');

		$('.modal-title').text('Formulario Nuevo Registro');

		$('#txtNom').val('');
		$('#txtApe').val('');
		$('#txtFnac').val('');
		$('#txtEmail').val('');
		$('#txtCarre').val('');
		$('#txtSeme').val('');
		$('#txtCurso').val('');
		$('#txtValo').val('');
		$('#txtGrado').val('');

		$('#btnAction').text('Enviar');
		$('#btnAction').val('Insertar');
	});

	$('#btnAction').click(function(){
		let id = $('#txtid').val();
		let nom = $('#txtNom').val();
		let ape = $('#txtApe').val();
		let fnac = $('#txtFnac').val();
		let email = $('#txtEmail').val();
		let carre = $('#txtCarre').val();
		let seme = $('#txtSeme').val();
		let curso = $('#txtCurso').val();
		let valo = $('#txtValo').val();
		let grado = $('#txtGrado').val();

		let op = $('#btnAction').val();

		$.ajax({
			url: 'procesos.php',
			method: 'POST',
			data:{crud:op, Id:id, Nom:nom, Ape:ape, Fnac:fnac, Email:email, Carre:carre, Seme:seme, Curso:curso, Valo:valo, Grado:grado},
			success:function(data){
				$('#formulario-modal').modal('hide');
				alert(data);
				Vista();
			}
		});
	});

	$(document).on('click', '.actualizar', function(){
		let id = $(this).attr('id');
		let op = 'Buscar';
		$.ajax({
			url:'procesos.php',
			method:'POST',
			data:{crud: op, Id:id},
			dataType: "json",

			success:function(data){
				$('#formulario-modal').modal('show');
				$('.modal-title').text('Formulario Actualizar Registro');

				$('#txtid').val(data.id);
				$('#txtNom').val(data.Nombre);
				$('#txtApe').val(data.Apellidos);
				$('#txtFnac').val(data.FechaNacimiento);
				$('#txtEmail').val(data.Email);
				$('#txtCarre').val(data.Carrera);
				$('#txtSeme').val(data.Semestre);
				$('#txtCurso').val(data.Curso);
				$('#txtValo').val(data.Valoracion);
				$('#txtGrado').val(data.Grado);

				$('#btnAction').text('Actualizar');
				$('#btnAction').val('Actualizar');
			}
		});
	});


	$(document).on('click', '.delete', function(){
		let id = $(this).attr('id');
		if(confirm('Estas seguro que deseas eliminar el registro?')){
			let op = "Eliminar";
			$.ajax({
				url: "procesos.php",
				method: "POST",
				data:{crud:op, Id:id},

				success:function(data){
					Vista();
					alert(data);
				}
			})
		}

	});


});
