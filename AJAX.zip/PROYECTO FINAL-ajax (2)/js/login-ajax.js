$('#btnIngresar').text('Ingresar');
$('#btnIngresar').val('Ingresar');


$('#btnRegistro').val('Registro');

$('#btnIngresar').click(function(){

	let user = $('#username').val();
	let pass = $('#password').val();

	let op = $('#btnIngresar').val();

	$.ajax({
		url: "procesos.php",
		method: "POST",
		data:{crud:op, Username:user, Password:pass},
		success:function(data){
			alert(data);
			if(data == "Confirmado"){
				location.href="vista.html";
			}
		}
	});
});

$('#btnRegistro').click(function(){
	$('#formulario-registro').modal('show');
	$('.modal-title').text('Registrate');

	$('#CorreoRegistro').val('');
	$('#ContraseñaRegistro').val('');

	$('#btnEnviar').text('Registrarse');
	$('#btnEnviar').val('Registro');
});


$('#btnEnviar').click(function(){
	let CorreoRegis = $('#CorreoRegistro').val();
	let ContraseñaRegis = $('#ContraseñaRegistro').val();

	let op = $('#btnEnviar').val();

	$.ajax({
		url: "procesos.php",
		method: "POST",
		data:{crud:op, CorreoRegistro:CorreoRegis, ContraseñaRegistro:ContraseñaRegis},
		success:function(data){
			$('#formulario-registro').modal('hide');
			alert(data);
		}
	});
});