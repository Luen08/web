<?php 
$i=1;

$j=2;

Echo $i=$j=--$i;
 ?>