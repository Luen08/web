$(document).ready(function () {
    $('#tb').DataTable( {
        language:{
            url: '../../js/español.json'
        },  
        responsive: "true",
    } );
} );