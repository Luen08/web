$(document).ready(function () {
    $('#tbDirectores').DataTable( {
        language:{
            url: '../../js/español.json'
        },  
        responsive: "true",
    } );
} );

$("#btnIngresarDirector").text("Insertar Director");

$(".modal-title").text("Ingresar Director");



$("#btnIngresarDirec").text("Guardar");
$("#btnIngresarDirec").val("insertarDirector");

$("#btnIngresarDirec").click(function(){
    let op = $("#btnIngresarDirec").val();
    let Nombre = $("#txtNombre").val();
    let Apellido = $("#txtApellido").val();
    let Anio = $("#txtAnio").val();
    let Pais = $("#txtPais").val();
    let Peli = $("#txtPelicula").val();

    if(Nombre == "" || Apellido == "" || Anio == "" || Pais ==""){
        alert("datos vacios");
    }else{
        $.ajax({
            url: "../../include/procesos.php",
            method: "POST",
            data:{
                crud:op,
                Name:Nombre,
                LastName:Apellido,
                YearNac:Anio,
                Country:Pais,
                Movie:Peli
            },
            success:function(data){
                alert(data);
                $("#staticBackdrop").modal("hide");
                location.href="directores.php";
            }
        });
    }

    
});


$(document).on('click', '.UpdateDirector', function(){
    let id = $(this).attr('id');
    let op = "buscarDirec";
    

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {crud:op,Id:id},
        dataType: "json",
        success:function(data){
            alert(data);
            $("#staticBackdrop1").modal("show");
            $(".modal-title1").text("Actualizar datos de Director");
            
            $('#txtId1').val(data[0]);
            $('#txtNombre1').val(data.director_Nombre);
            $('#txtApellido1').val(data.director_Apellido);
            $('#txtAnio1').val(data.director_Anio_nacimiento);
            $('#txtPais1').val(data.director_nacionalidad);
            $('#txtPelicula1').val(data.pelicula_id);

            $('#btnActualizarDirector').text("Actualizar");
            $("#btnActualizarDirector").val("actualizarDirec");
        }
    });
});

$('#btnActualizarDirector').click(function(){
    $("#staticBackdrop1").modal("hide");

    let op = $("#btnActualizarDirector").val();
    let id = $('#txtId1').val();
    let Nombre = $("#txtNombre1").val();
    let Apellido = $("#txtApellido1").val();
    let Anio = $("#txtAnio1").val();
    let Pais = $("#txtPais1").val();
    let Peli = $("#txtPelicula1").val();

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {
            crud:op,
            Id:id,
            Name:Nombre,
            LastName:Apellido,
            YearNac:Anio,
            Country:Pais,
            Movie:Peli
        },
        success:function(data){
            alert(data);
            location.href="directores.php";

        }
    });
});

$(document).on('click', '.DeleteDirector', function(){
    let id = $(this).attr('id');
    let op = "eliminarDirector";

    if(confirm("Estas seguro que deseas eliminar al director?")){
        $.ajax({
            url: "../../include/procesos.php",
            method: 'POST',
            data: {crud:op, Id:id},
            success:function(data){
                alert(data);     
                location.href="directores.php";
            }
        });
    }
    


});
