$("#btnBuscarDni").text("Buscar");
$("#btnBuscarDni").val("BuscarDni");

$('#btnBuscarDni').click(function(){
    let dni = $("#inDni").val();
    let op = $("#btnBuscarDni").val();

    $.ajax({
        url: "./include/procesos.php",
        method: "POST",
        data:{
            crud:op, Dni:dni
        },
        dataType: "json",
        success:function(data){

            $("#inNombre").val(data["nombres"]);
            $("#inPaterno").val(data.apellidoPaterno);
            $("#inMaterno").val(data.apellidoMaterno);
        }
    });
});

$("#btnRegistro").text("Registrate");
$("#btnRegistro").val("registro");

$('#btnRegistro').click(function(){
    let inDni = $("#inDni").val();
    let inNom = $("#inNombre").val();
    let inPaterno = $("#inPaterno").val();
    let inMaterno = $("#inMaterno").val();
    let inCorreo = $("#inCorreo").val();
    let inPwd = $("#inPwd").val();
    let op = $("#btnRegistro").val();

    $("#inDni").val("");
    $("#inNombre").val("");
    $("#inPaterno").val("");
    $("#inMaterno").val("");
    $("#inCorreo").val("");
    $("#inPwd").val("");

    $.ajax({
        url: "./include/procesos.php",
        method: "POST",
        data:{
            crud:op, 
            Dni:inDni, 
            Nombre:inNom, 
            Paterno:inPaterno, 
            Materno:inMaterno, 
            Correo:inCorreo, 
            pwd:inPwd
        },
        success:function(data){
            alert(data);
            $("#cerrar").click();
        }
    });
});