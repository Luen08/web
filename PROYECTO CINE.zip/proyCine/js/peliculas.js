$(document).ready(function () {
    $('#tbPelis').DataTable( {
        language:{
            url: '../../js/español.json'
        },  
        responsive: "true",
    } );
} );

$("#btnIngresarPeli").text("Insertar Pelicula");
$("#btnIngresarPeli").val("IngresarPeli");
$(".tittle_pelis").text("Ingresar Pelicula");

$('#btnIngresarPeli').click(function(){
    $("#txtTitleMovie").val("")
    $("#txtSinopsis").val("");
    $("#txtValoracion").val("");
    $("#txtGenero").val("");
    $("#txtDuracion").val("");
    $("#txtAnio").val("");
    $("#txtLinkImage").val("");
    $("#txtLinkVideo").val("");
});


$('#btnBuscarPeli').click(function(){
    let key = "8c74b0c3";
    let nameMovie = $("#txtTitleMovie").val();
    let url = "https://www.omdbapi.com/?t="+nameMovie+"&apikey="+key;

    if (nameMovie.length <= 0) {
        alert("campo vacio");
    }
    else {
        fetch(url).then((resp) => resp.json()).then((data) => {
            //si la película existe en la base de datos
            console.log(data);
            if (data.Response == "True") {
                $("#txtTitleMovie").val(data.Title)
                $("#txtSinopsis").val(data.Plot);
                $("#txtValoracion").val(data.imdbRating);
                $("#txtGenero").val(data.Genre);
                $("#txtDuracion").val(data.Runtime);
                $("#txtAnio").val(data.Year);
                $("#txtLinkImage").val(data.Poster);
            }
        })

    }
    

});

$("#btnActionPeli").text("Guardar");
$("#btnActionPeli").val("insertarPeli");

$('#btnActionPeli').click(function(){
    let op = $("#btnActionPeli").val();
    let title = $("#txtTitleMovie").val();
    let plot = $("#txtSinopsis").val();
    let rat = $("#txtValoracion").val();
    let genr = $("#txtGenero").val();
    let time = $("#txtDuracion").val();
    let year = $("#txtAnio").val();
    let link_image = $("#txtLinkImage").val();
    let link_video = $("#txtLinkVideo").val();


    if(title == "" || plot == ""){
        alert("Datos vacios");
    }else{
        $.ajax({
            url: "../../include/procesos.php",
            method: "POST",
            data:{
                crud:op,
                titulo:title,
                sinopsis:plot,
                val:rat,
                genero:genr,
                duracion:time,
                anio:year,
                url_image:link_image,
                url_video:link_video
            },
            success:function(data){
                alert(data);
                $("#formulario-modal-pelis").modal("hide");
                location.href="peliculas.php";
            }
        });
    }
    

});

$(document).on('click', '.UpdatePeli', function(){
    let id = $(this).attr('id');
    let op = "buscarPeli";
    

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {crud:op,Id:id},
        dataType: "json",
        success:function(data){
            $("#formulario-modal-actualizar-pelis").modal("show");
            $(".tittle_actualizar_pelis").text("Actualizar datos de Pelicula");
            $('#txtId1').val(data[0]);
            $('#txtTitulo1').val(data.pelicula_titulo);
            $('#txtSinopsis1').val(data.pelicula_sinopsis);
            $('#txtValoracion1').val(data.pelicula_valoracion);
            $('#txtGenero1').val(data.pelicula_genero);
            $('#txtDuracion1').val(data.pelicula_duracion);
            $('#txtAnio1').val(data.pelicula_anio);
            $('#txtLinkImage1').val(data.pelicula_link_image);
            $('#txtLinkVideo1').val(data.pelicula_link_video);
            $('#btnActionActualizarPeli').text("Actualizar");
            $("#btnActionActualizarPeli").val("actualizarPeli");
        }
    });
    
});

$('#btnActionActualizarPeli').click(function(){
    $("#formulario-modal-actualizar-pelis").modal("hide");

    let op = $("#btnActionActualizarPeli").val();
    let id = $('#txtId1').val();
    let Titulo = $("#txtTitulo1").val();
    let Sinopsis = $("#txtSinopsis1").val();
    let Valo = $("#txtValoracion1").val();
    let Genero = $("#txtGenero1").val();
    let Dura = $("#txtDuracion1").val();
    let Anio = $("#txtAnio1").val();
    let url_image = $("#txtLinkImage1").val();
    let url_video = $("#txtLinkVideo1").val();

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {
            crud:op, 
            Id_peli:id, 
            Title:Titulo, 
            Plot:Sinopsis, 
            Rat:Valo, 
            Genre:Genero, 
            Time:Dura, 
            Year:Anio,
            Link_image:url_image,
            Link_video: url_video
        },
        success:function(data){
            alert(data);
            location.href="peliculas.php";

        }
    });
});

$(document).on('click', '.DeletePeli', function(){
    let id = $(this).attr('id');
    let op = "eliminarPeli";

    if(confirm("Estas seguro que deseas eliminar la pelicula?")){
        $.ajax({
            url: "../../include/procesos.php",
            method: 'POST',
            data: {crud:op, Id:id},
            success:function(data){
                alert(data);     
                location.href="peliculas.php";
            }
        });
    }
    


});
