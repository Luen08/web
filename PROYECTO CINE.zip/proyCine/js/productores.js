$(document).ready(function () {
    $('#tbProd').DataTable( {
        language:{
            url: '../../js/español.json'
        },  
        responsive: "true",
    } );
} );

$("#btnIngresarProductor").text("Insertar Productor");
$(".modal-title").text("Ingresar Productor");

$("#btnInsertarProduc").val("insertarProductor");
$("#btnInsertarProduc").text("Guardar");


$("#btnInsertarProduc").click(function(){
    let op = $("#btnInsertarProduc").val();
    let Nombre = $("#txtNombre").val();
    let Apellido = $("#txtApellido").val();
    let Anio = $("#txtAnio").val();
    let Pais = $("#txtPais").val();
    let Peli = $("#txtPelicula").val();

    if(Nombre == "" || Apellido == "" || Anio == "" || Pais ==""){
        alert("datos vacios");
    }else{
        $.ajax({
            url: "../../include/procesos.php",
            method: "POST",
            data:{
                crud:op,
                Name:Nombre,
                LastName:Apellido,
                YearNac:Anio,
                Country:Pais,
                Movie:Peli
            },
            success:function(data){
                alert(data);
                $("#staticBackdrop").modal("hide");
                location.href="productores.php";
            }
        });
    }
});

$(document).on('click', '.UpdateProductor', function(){
    let id = $(this).attr('id');
    let op = "buscarProd";
    

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {crud:op,Id:id},
        dataType: "json",
        success:function(data){
            $("#staticBackdrop1").modal("show");
            $(".modal-title1").text("Actualizar datos de productor");
            $('#txtId1').val(data[0]);
            $('#txtNombre1').val(data.productor_Nombre);
            $('#txtApellido1').val(data.productor_Apellido);
            $('#txtAnio1').val(data.productor_Anio_nacimiento);
            $('#txtPais1').val(data.productor_nacionalidad);
            $('#txtPelicula1').val(data.pelicula_id);

            $('#btnActualizarProductor').text("Actualizar");
            $("#btnActualizarProductor").val("actualizarProd");
        }
    });
    
});

$('#btnActualizarProductor').click(function(){
    $("#staticBackdrop1").modal("hide");

    let op = $("#btnActualizarProductor").val();
    let id = $('#txtId1').val();
    let Nombre = $("#txtNombre1").val();
    let Apellido = $("#txtApellido1").val();
    let Anio = $("#txtAnio1").val();
    let Pais = $("#txtPais1").val();
    let Peli = $("#txtPelicula1").val();

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {
            crud:op,
            Id:id,
            Name:Nombre,
            LastName:Apellido,
            YearNac:Anio,
            Country:Pais,
            Movie:Peli
        },
        success:function(data){
            alert(data);
            location.href="productores.php";

        }
    });
});

$(document).on('click', '.DeleteProductor', function(){
    let id = $(this).attr('id');
    let op = "eliminarProductor";

    if(confirm("Estas seguro que deseas eliminar al productor?")){
        $.ajax({
            url: "../../include/procesos.php",
            method: 'POST',
            data: {crud:op, Id:id},
            success:function(data){
                alert(data);     
                location.href="productores.php";
            }
        });
    }
    


});
