$(document).ready(function () {
    $('#tbActores').DataTable( {
        language:{
            url: '../../js/español.json'
        },  
        responsive: "true",
    } );
} );
$("#btnIngresarAct").text("Insertar Actor");
$("#btnIngresarAct").val("InsertarActor");

$(".modal-title").text("Ingresar Actor");

$("#btnIngresarAct").click(function(){
    $("#txtNombre").val("")
    $("#txtApellido").val("");
    $("#txtAnio").val("");
    $("#txtPais").val("");
});

$("#btnInsertarActor").text("Guardar");
$("#btnInsertarActor").val("insertarActor");

$("#btnInsertarActor").click(function(){
    let op = $("#btnInsertarActor").val();
    let Nombre = $("#txtNombre").val();
    let Apellido = $("#txtApellido").val();
    let Anio = $("#txtAnio").val();
    let Pais = $("#txtPais").val();
    let Peli = $("#txtPelicula").val();

    if(Nombre == "" || Apellido == "" || Anio == "" || Pais =="" || Peli == "Seleccionar una pelicula"){
        alert("datos vacios");
    }else{
        $.ajax({
            url: "../../include/procesos.php",
            method: "POST",
            data:{
                crud:op,
                Name:Nombre,
                LastName:Apellido,
                YearNac:Anio,
                Country:Pais,
                Movie:Peli
            },
            success:function(data){
                alert(data);
                $("#staticBackdrop").modal("hide");
                location.href="actores.php";
            }
        });
    }

    
});


$(document).on('click', '.UpdateActor', function(){
    let id = $(this).attr('id');
    let op = "buscarActu";
    

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {crud:op,Id:id},
        dataType: "json",
        success:function(data){
            $("#staticBackdrop1").modal("show");
            $(".modal-title1").text("Actualizar datos de Actores");
            $('#txtId1').val(data[0]);
            $('#txtNombre1').val(data.actor_Nombre);
            $('#txtApellido1').val(data.actor_Apellido);
            $('#txtAnio1').val(data.actor_Anio_nacimiento);
            $('#txtPais1').val(data.actor_nacionalidad);
            $('#txtPelicula1').val(data.pelicula_id);

            $('#btnActualizarActor').text("Actualizar");
            $("#btnActualizarActor").val("actualizarActor");
        }
    });
    
});

$('#btnActualizarActor').click(function(){
    $("#staticBackdrop1").modal("hide");

    let op = $("#btnActualizarActor").val();
    let id = $('#txtId1').val();
    let Nombre = $("#txtNombre1").val();
    let Apellido = $("#txtApellido1").val();
    let Anio = $("#txtAnio1").val();
    let Pais = $("#txtPais1").val();
    let Peli = $("#txtPelicula1").val();

    let qwe = $('#crud').val();

    $.ajax({
        url: "../../include/procesos.php",
        method: 'POST',
        data: {
            crud:op,
            Id:id,
            Name:Nombre,
            LastName:Apellido,
            YearNac:Anio,
            Country:Pais,
            Movie:Peli
        },
        success:function(data){
            alert(data);
            location.href="actores.php";

        }
    });
});

$(document).on('click', '.DeleteActor', function(){
    let id = $(this).attr('id');
    let op = "eliminarActor";

    if(confirm("Estas seguro que deseas eliminar al actor?")){
        $.ajax({
            url: "../../include/procesos.php",
            method: 'POST',
            data: {crud:op, Id:id},
            success:function(data){
                alert(data);     
                location.href="actores.php";
            }
        });
    }
    


});
