drop database cinema;
CREATE DATABASE cinema;
use cinema;

create table cargo(
	cargo_id int auto_increment,
    cargo_nombre varchar(5),
    constraint pk_cargo primary key(cargo_id)
);

create table persona(
	persona_id int auto_increment,
    persona_dni varchar(8) not null,
    persona_Nombre varchar(80),
    persona_ApellidoPa varchar(50),
    persona_ApellidoMa varchar(50),
    persona_Correo varchar(70),
    constraint pk_persona primary key(persona_id)
);

create table usuario(
	usuario_id int  auto_increment,
    persona_id int,
    usuario_correo varchar(70),
    usuario_contrasenia varchar(50),
    cargo_id int,
    constraint pk_usuario primary key(usuario_id),
    constraint fk_cargo foreign key(cargo_id) references cargo(cargo_id),
    constraint fk_persona foreign key(persona_id) references persona(persona_id)
);

create table pelicula(
	pelicula_id int auto_increment,
    pelicula_titulo varchar(50),
    pelicula_sinopsis varchar(250),
    pelicula_valoracion varchar(15),
    pelicula_genero varchar(70),
    pelicula_duracion varchar(10),
    pelicula_anio varchar(15),
    pelicula_link_image varchar(250),
    pelicula_link_video varchar(250),
    constraint pk_pelicula primary key(pelicula_id)
);

create table actor(
	actor_id int auto_increment,
    actor_Nombre varchar(20),
    actor_Apellido varchar(25),
    actor_Anio_nacimiento varchar(4),
    actor_nacionalidad varchar(15),
    pelicula_id int,
    constraint pk_actor primary key(actor_id),
    constraint fk_pelicula foreign key(pelicula_id)references pelicula(pelicula_id)
);

create table director(
	director_id int auto_increment,
    director_Nombre varchar(20),
    director_Apellido varchar(25),
    director_Anio_nacimiento varchar(4),
    director_nacionalidad varchar(15),
    pelicula_id int,
    constraint pk_director primary key(director_id),
    constraint fk_pelicula_1 foreign key(pelicula_id)references pelicula(pelicula_id)
);

create table productor(
	productor_id int auto_increment,
    productor_Nombre varchar(20),
    productor_Apellido varchar(25),
    productor_Anio_nacimiento varchar(4),
    productor_nacionalidad varchar(15),
    pelicula_id int,
    constraint pk_productor primary key(productor_id),
    constraint fk_pelicula_2 foreign key(pelicula_id)references pelicula(pelicula_id)
);