<?php
    require_once("../include/conexion.php");

    $cn = ConexionMysql::Conectarse();

    if(isset($_POST["crud"])){
        if($_POST["crud"] == "BuscarDni" ){
            $dni = $_POST["Dni"];

            $json_url = "https://dniruc.apisperu.com/api/v1/dni/".$dni."?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6Imx1ZW4uY2cwOEBnbWFpbC5jb20ifQ.tAvSCAS9xvp1AeZEg9-FP71WmX-4zsS_dDCpOj-zG8M";
            $json = file_get_contents($json_url);
            $data = json_decode($json, TRUE);
            echo json_encode($data);
        }

        if($_POST["crud"] == "registro"){
            $insert = $cn->prepare("call sp_insertar_persona(:dato1, :dato2, :dato3, :dato4, :dato5);");
            $insert->bindParam(":dato1", $_POST["Dni"]);
            $insert->bindParam(":dato2", $_POST["Nombre"]);
            $insert->bindParam(":dato3", $_POST["Paterno"]);
            $insert->bindParam(":dato4", $_POST["Materno"]);
            $insert->bindParam(":dato5", $_POST["Correo"]);

            try {
                $rpta = $insert->execute();
                echo'FELICIDADES...';
            } catch (PDOException $e) {
                echo'Error no se Inserto';
                echo $e->getMessage();
            }


            $insert->closeCursor();
            $insert = null;

            $insert = $cn->prepare("call sp_search_persona_dni(:dato1);");
            $insert->bindParam(":dato1", $_POST["Dni"]);
            $insert->execute();

            $result = $insert->fetchAll();
            foreach($result as $fila){
                $id_persona = $fila["persona_id"];

            }

            $insert->closeCursor();
            $insert = null;

            $insert = $cn->prepare("call sp_insertar_usuario(:dato1, :dato2, :dato3);");
            $insert->bindParam(":dato1", $id_persona);
            $insert->bindParam(":dato2", $_POST["Correo"]);
            $insert->bindParam(":dato3", $_POST["pwd"]);
            
            try {
                $rpta = $insert->execute();
                echo'YA ERES PARTE DE CINEMA INFO';
            } catch (PDOException $e) {
                echo'Error no se Inserto';
                echo $e->getMessage();
            }

            $insert->closeCursor();
            $insert = null;
        }

        if($_POST["crud"] == "insertarPeli"){
            $insert = $cn->prepare("call sp_insertar_peliculas(:dato1, :dato2, :dato3, :dato4, :dato5, :dato6, :dato7, :dato8);");
            $insert->bindParam(":dato1", $_POST["titulo"]);
            $insert->bindParam(":dato2", $_POST["sinopsis"]);
            $insert->bindParam(":dato3", $_POST["val"]);
            $insert->bindParam(":dato4", $_POST["genero"]);
            $insert->bindParam(":dato5", $_POST["duracion"]);
            $insert->bindParam(":dato6", $_POST["anio"]);
            $insert->bindParam(":dato7", $_POST["url_image"]);
            $insert->bindParam(":dato8", $_POST["url_video"]);

            
            try {
                $rpta = $insert->execute();
                echo'Pelicula insertada satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Inserto';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "insertarActor"){
            $insert = $cn->prepare("call sp_insertar_actores(:dato1, :dato2, :dato3, :dato4, :dato5);");
            $insert->bindParam(":dato1", $_POST["Name"]);
            $insert->bindParam(":dato2", $_POST["LastName"]);
            $insert->bindParam(":dato3", $_POST["YearNac"]);
            $insert->bindParam(":dato4", $_POST["Country"]);
            $insert->bindParam(":dato5", $_POST["Movie"]);

            
            try {
                $rpta = $insert->execute();
                echo'Actor insertada satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Inserto';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "insertarDirector"){
            $insert = $cn->prepare("call sp_insertar_directores(:dato1, :dato2, :dato3, :dato4, :dato5);");
            $insert->bindParam(":dato1", $_POST["Name"]);
            $insert->bindParam(":dato2", $_POST["LastName"]);
            $insert->bindParam(":dato3", $_POST["YearNac"]);
            $insert->bindParam(":dato4", $_POST["Country"]);
            $insert->bindParam(":dato5", $_POST["Movie"]);

            
            try {
                $rpta = $insert->execute();
                echo'Director insertada satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Inserto';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "insertarProductor"){
            $insert = $cn->prepare("call sp_insertar_productores(:dato1, :dato2, :dato3, :dato4, :dato5);");
            $insert->bindParam(":dato1", $_POST["Name"]);
            $insert->bindParam(":dato2", $_POST["LastName"]);
            $insert->bindParam(":dato3", $_POST["YearNac"]);
            $insert->bindParam(":dato4", $_POST["Country"]);
            $insert->bindParam(":dato5", $_POST["Movie"]);

            
            try {
                $rpta = $insert->execute();
                echo'Productor insertada satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Inserto';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "buscarPeli"){
            $buscar = $cn->prepare("call sp_search_pelicula(:dato1);");
            $buscar->bindParam(":dato1", $_POST["Id"]);

            $buscar->execute();
            $fin = $buscar->fetch();
            
            echo json_encode($fin);

        }

        if($_POST["crud"] == "actualizarPeli"){
            $edit = $cn->prepare("call sp_update_peliculas(:dato1, :dato2, :dato3, :dato4, :dato5,:dato6, :dato7, :dato8, :dato9);");
            $edit->bindParam(":dato1", $_POST["Id_peli"]);
            $edit->bindParam(":dato2", $_POST["Title"]);
            $edit->bindParam(":dato3", $_POST["Plot"]);
            $edit->bindParam(":dato4", $_POST["Rat"]);
            $edit->bindParam(":dato5", $_POST["Genre"]);
            $edit->bindParam(":dato6", $_POST["Time"]);
            $edit->bindParam(":dato7", $_POST["Year"]);
            $edit->bindParam(":dato8", $_POST["Link_image"]);
            $edit->bindParam(":dato9", $_POST["Link_video"]);

            
            try {
                $rpta = $edit->execute();
                echo'Pelicula Actualizada satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Actualizo';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "eliminarPeli"){
            $eliminar = $cn->prepare("call sp_delete_peliculas(:dato1);");
            $eliminar->bindParam(":dato1", $_POST["Id"]);

            try {
                $rpta = $eliminar->execute();
                echo'Pelicula Eliminada satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Elimino';
                echo $e->getMessage();
            }

        }

        if($_POST["crud"] == "buscarActu"){
            $buscar = $cn->prepare("call sp_search_actor(:dato1);");
            $buscar->bindParam(":dato1", $_POST["Id"]);

            $buscar->execute();
            $fin = $buscar->fetch();
            
            echo json_encode($fin);

        }

        if($_POST["crud"] == "actualizarActor"){
            $edit = $cn->prepare("call sp_update_actores(:dato1, :dato2, :dato3, :dato4, :dato5, :dato6);");
            $edit->bindParam(":dato1", $_POST["Id"]);
            $edit->bindParam(":dato2", $_POST["Name"]);
            $edit->bindParam(":dato3", $_POST["LastName"]);
            $edit->bindParam(":dato4", $_POST["YearNac"]);
            $edit->bindParam(":dato5", $_POST["Country"]);
            $edit->bindParam(":dato6", $_POST["Movie"]);

            
            try {
                $rpta = $edit->execute();
                echo'Actor actualizado satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se actualizo';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "eliminarActor"){
            $eliminar = $cn->prepare("call sp_delete_actores(:dato1);");
            $eliminar->bindParam(":dato1", $_POST["Id"]);

            try {
                $rpta = $eliminar->execute();
                echo'Actor eliminado satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Elimino';
                echo $e->getMessage();
            }

        }

        if($_POST["crud"] == "buscarDirec"){
            $buscar = $cn->prepare("call sp_search_director(:dato1);");
            $buscar->bindParam(":dato1", $_POST["Id"]);

            $buscar->execute();
            $fin = $buscar->fetch();
            
            echo json_encode($fin);
        }

        if($_POST["crud"] == "actualizarDirec"){
            $edit = $cn->prepare("call sp_update_directores(:dato1, :dato2, :dato3, :dato4, :dato5, :dato6);");
            $edit->bindParam(":dato1", $_POST["Id"]);
            $edit->bindParam(":dato2", $_POST["Name"]);
            $edit->bindParam(":dato3", $_POST["LastName"]);
            $edit->bindParam(":dato4", $_POST["YearNac"]);
            $edit->bindParam(":dato5", $_POST["Country"]);
            $edit->bindParam(":dato6", $_POST["Movie"]);

            
            try {
                $rpta = $edit->execute();
                echo'Director actualizado satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se actualizo';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "eliminarDirector"){
            $eliminar = $cn->prepare("call sp_delete_directores(:dato1);");
            $eliminar->bindParam(":dato1", $_POST["Id"]);

            try {
                $rpta = $eliminar->execute();
                echo'director eliminado satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Elimino';
                echo $e->getMessage();
            }

        }

        if($_POST["crud"] == "buscarProd"){
            $buscar = $cn->prepare("call sp_search_productor(:dato1);");
            $buscar->bindParam(":dato1", $_POST["Id"]);

            $buscar->execute();
            $fin = $buscar->fetch();
            
            echo json_encode($fin);
        }

        if($_POST["crud"] == "actualizarProd"){
            $edit = $cn->prepare("call sp_update_productores(:dato1, :dato2, :dato3, :dato4, :dato5, :dato6);");
            $edit->bindParam(":dato1", $_POST["Id"]);
            $edit->bindParam(":dato2", $_POST["Name"]);
            $edit->bindParam(":dato3", $_POST["LastName"]);
            $edit->bindParam(":dato4", $_POST["YearNac"]);
            $edit->bindParam(":dato5", $_POST["Country"]);
            $edit->bindParam(":dato6", $_POST["Movie"]);

            
            try {
                $rpta = $edit->execute();
                echo'PRODUCTOR actualizado satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se actualizo';
                echo $e->getMessage();
            }
        }

        if($_POST["crud"] == "eliminarProductor"){
            $eliminar = $cn->prepare("call sp_delete_productores(:dato1);");
            $eliminar->bindParam(":dato1", $_POST["Id"]);

            try {
                $rpta = $eliminar->execute();
                echo'PRODUCTOR eliminado satisfactoriamente';
            } catch (PDOException $e) {
                echo'Error no se Elimino';
                echo $e->getMessage();
            }

        }

    }

?>