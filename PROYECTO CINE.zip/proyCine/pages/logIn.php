<?php 
session_start();
session_destroy();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <link rel="stylesheet" href="../css/styleLogin.css" type="text/css">
    <!-- JQUERY -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- FONTAWESOME -->
    <script src="https://kit.fontawesome.com/d1776a2738.js" crossorigin="anonymous"></script>
    <title>Log-in</title>
</head>
<body>
    <section>
        <div class="color"></div>
        <div class="color"></div>
        <div class="color"></div>
        <div class="box">
            <div class="square" style="--i:0;"></div>
			<div class="square" style="--i:1;"></div>
			<div class="square" style="--i:2;"></div>
			<div class="square" style="--i:3;"></div>
			<div class="square" style="--i:4;"></div>
            <div class="container">
                <div class="form">
                    <h2>Iniciar sesión</h2>
                    <form action="index.php" method="post">
                        <div class="inputBox inputBox--icono">
                            <label class="inputBox__ico" for="username">
                                <i class="ico fa-sharp fa-solid fa-user"></i>
                            </label>
                            <input type="text" placeholder="Correo Electronico" name="username" id="username">
                        </div>
                        <div class="inputBox inputBox--icono">
                            <label class="inputBox__ico" for="password">
                                <i class="ico fa-sharp fa-solid fa-key"></i>
                            </label>
                            <input type="password" placeholder="Contraseña" name="password" id="password">
                        </div>
                        <div class="inputBox">
                            <button type="submit" name="iniciar" id="btnIngresar">Iniciar Sesión</button>
                        </div>
                        <div class="inputBox">
                            <label class="inputBox__recContraseña">Olvidaste tu contraseña? <a href="#" class="inputBox__link">Click Aquí</a></label>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
</html>