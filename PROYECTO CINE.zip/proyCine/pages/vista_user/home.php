<?php
session_start();

if(!isset($_SESSION['id_persona'])){
    header('location: ../logIn.php');

    session_destroy();

    die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/styleHomeUser.css">
    <script src="https://kit.fontawesome.com/54a24d044d.js" crossorigin="anonymous"></script>
    <title>Home</title>
</head>
<body>
<?php
    $id = $_SESSION["id_persona"];

    $crud = "inicio";

    include '../../include/conexion.php';
    $cn = ConexionMysql::Conectarse();

    if ($crud) {
        if ($crud == "inicio") {
            $vista = $cn->prepare("call sp_vista_peliculas();");
            $vista->execute();

            $visualizacion = $vista->fetchAll();
            foreach ($visualizacion as $fila) {
                $id_movie = $fila["pelicula_id"];
                $Title_peli = $fila["pelicula_titulo"];
                $Plot_peli = $fila["pelicula_sinopsis"];
                $Val_peli = $fila["pelicula_valoracion"];
                $Genr_peli = $fila["pelicula_genero"];
                $Dur_peli = $fila["pelicula_duracion"];
                $Anio_peli = $fila["pelicula_anio"];
                $Poster_peli = $fila["pelicula_link_image"];
                $Trailer_peli = $fila["pelicula_link_video"];
            }
            $vista->closeCursor();
            $vista = null;
        }
    }

    ?>
    <?php include("nav.html");?>
    <main>
        <div class="pelicula-principal" style="background-image: linear-gradient(rgba(0,0,0, .50)0%, rgba(0,0,0, .50)100%),url(<?php echo $Poster_peli;?>); ">
            <div class="contenedor">
                <h3 class="titulo"> <?php echo $Title_peli; ?></h3>
                <p class="descripcion"><?php echo $Plot_peli; ?></p>
                <a href="<?php echo $Trailer_peli;?>" role="button" class="boton"><i class="fa-solid fa-play"></i>Reproducir</a>
                <a href="request.php?pel=<?php echo $id_movie?>" role="button" class="boton"><i class="fa-solid fa-circle-info"></i>Mas informacion</a>

            </div>
        </div>
    </main>
</body>
<?php include("../../include/footer.php")?>
</html>