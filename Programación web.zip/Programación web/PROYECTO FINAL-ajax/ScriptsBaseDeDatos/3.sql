-- SERVICIOS CRUD
-- VER TODO
use dbproyecto;
drop procedure if exists spVistaProfesores;
delimiter //
create procedure spVistaProfesores()
begin 
	select * from profesores;
end //
delimiter ;

call spVistaProfesores();

-- BUSCAR NOMBRE Y APELLIDO
use dbproyecto;
drop procedure if exists spBuscarNombreApellido;
delimiter //
create procedure spBuscarNombreApellido(
	in BuscarTexto varchar(50)
)
begin 
	select * from profesores where concat(Nombre,Apellidos) like concat('%',BuscarTexto,'%');
end //
delimiter ;

-- INSERTAR PROFESOR
use dbproyecto;
drop procedure if exists spInsertarProfesores;
delimiter //
create procedure spInsertarProfesores(
	in
	_Nombre Varchar(50),
	_Apellidos varchar(50),
	_FechaNacimiento date,
    _Email varchar(100),
    _Carrera varchar(50),
    _Semestre int,
    _Curso varchar(50),
    _Valoracion int,
    _Grado varchar(50)
)
begin 
	insert into Profesores(Nombre,Apellidos,FechaNacimiento,Edad,Email,Carrera,Semestre,Curso,Valoracion,Grado)
	values(_Nombre, _Apellidos, _FechaNacimiento, FnEdad(_FechaNacimiento), _Email, _Carrera, _Semestre, _Curso, _Valoracion, _Grado);
end //
delimiter ;

-- EDITAR PROFESOR
use dbproyecto;
drop procedure if exists spEditarProfesores;
delimiter //
create procedure spEditarProfesores(
	in
    _id int,
    _Nombre Varchar(50),
	_Apellidos varchar(50),
	_FechaNacimiento date,
    _Email varchar(100),
    _Carrera varchar(50),
    _Semestre int,
    _Curso varchar(50),
    _Valoracion int,
    _Grado varchar(50)
)
begin 
	update profesores set Nombre = _Nombre, Apellidos = _Apellidos, FechaNacimiento = _FechaNacimiento, Email = _Email, Semestre = _Semestre, Curso = _Curso, Valoracion = _Valoracion, Grado = _Grado where id = _id;
end //
delimiter ;

-- ELIMINAR PROFESORES
use dbproyecto;
drop procedure if exists spEliminarProfesores;
delimiter //
create procedure spEliminarProfesores(
	in
    _id int
)
begin 
	delete from profesores where id = _id;
end //
delimiter ;

-- BUSCAR POR DNI
use dbproyecto;
drop procedure if exists spBuscarId;
delimiter //
create procedure spBuscarId(
	in Buscarid varchar(50)
)
begin 
	select * from profesores where id = Buscarid;
end //
delimiter ;